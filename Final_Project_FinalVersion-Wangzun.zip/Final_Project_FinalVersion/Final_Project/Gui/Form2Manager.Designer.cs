﻿namespace Final_Project.Gui
{
    partial class Form2Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ListView1 = new System.Windows.Forms.ListView();
            this.User_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.First_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Last_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Department = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Login_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Password = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.ButtonSearch1 = new System.Windows.Forms.Button();
            this.ComboBoxSearch1 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch1 = new System.Windows.Forms.TextBox();
            this.LabelEnter = new System.Windows.Forms.Label();
            this.LabelSearchBy = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.TextBoxPassword = new System.Windows.Forms.TextBox();
            this.ButtonReset = new System.Windows.Forms.Button();
            this.LabelPassword = new System.Windows.Forms.Label();
            this.ButtonDelete1 = new System.Windows.Forms.Button();
            this.TextBoxLoginId = new System.Windows.Forms.TextBox();
            this.ButtonUpdate1 = new System.Windows.Forms.Button();
            this.TextBoxDepartment = new System.Windows.Forms.TextBox();
            this.ButtonSave1 = new System.Windows.Forms.Button();
            this.TextBoxLastName = new System.Windows.Forms.TextBox();
            this.TextBoxUserId = new System.Windows.Forms.TextBox();
            this.TextBoxFirstName = new System.Windows.Forms.TextBox();
            this.LabelUserId = new System.Windows.Forms.Label();
            this.LabelLoginId = new System.Windows.Forms.Label();
            this.LabelFirstName = new System.Windows.Forms.Label();
            this.LabelDepartment = new System.Windows.Forms.Label();
            this.LabelLastName = new System.Windows.Forms.Label();
            this.LabelDigits = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TextBoxEmail = new System.Windows.Forms.TextBox();
            this.TextBoxPN = new System.Windows.Forms.TextBox();
            this.TextBoxLN = new System.Windows.Forms.TextBox();
            this.TextBoxFN = new System.Windows.Forms.TextBox();
            this.LabelEmail = new System.Windows.Forms.Label();
            this.LabelPN = new System.Windows.Forms.Label();
            this.Label3Digits = new System.Windows.Forms.Label();
            this.LabelLN = new System.Windows.Forms.Label();
            this.LabelFN = new System.Windows.Forms.Label();
            this.TextBoxID = new System.Windows.Forms.TextBox();
            this.LabelID = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.ButtonCP1 = new System.Windows.Forms.Button();
            this.TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.tabPage1);
            this.TabControl1.Controls.Add(this.tabPage2);
            this.TabControl1.Location = new System.Drawing.Point(31, 12);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(822, 413);
            this.TabControl1.TabIndex = 0;
            this.TabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.ListView1);
            this.tabPage1.Controls.Add(this.GroupBox2);
            this.tabPage1.Controls.Add(this.GroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(814, 387);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "UserControl";
            // 
            // ListView1
            // 
            this.ListView1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.User_ID,
            this.First_Name,
            this.Last_Name,
            this.Department,
            this.Login_ID,
            this.Password});
            this.ListView1.GridLines = true;
            this.ListView1.Location = new System.Drawing.Point(16, 210);
            this.ListView1.Name = "ListView1";
            this.ListView1.Size = new System.Drawing.Size(772, 160);
            this.ListView1.TabIndex = 8;
            this.ListView1.UseCompatibleStateImageBehavior = false;
            this.ListView1.View = System.Windows.Forms.View.Details;
            this.ListView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView1_MouseClick);
            // 
            // User_ID
            // 
            this.User_ID.Text = "User_ID";
            this.User_ID.Width = 73;
            // 
            // First_Name
            // 
            this.First_Name.Text = "First_Name";
            this.First_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.First_Name.Width = 139;
            // 
            // Last_Name
            // 
            this.Last_Name.Text = "Last_Name";
            this.Last_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Last_Name.Width = 128;
            // 
            // Department
            // 
            this.Department.Text = "Department";
            this.Department.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Department.Width = 159;
            // 
            // Login_ID
            // 
            this.Login_ID.Text = "Login_ID";
            this.Login_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Login_ID.Width = 111;
            // 
            // Password
            // 
            this.Password.Text = "Password";
            this.Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Password.Width = 95;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.ButtonCP1);
            this.GroupBox2.Controls.Add(this.ButtonExit);
            this.GroupBox2.Controls.Add(this.button6);
            this.GroupBox2.Controls.Add(this.ButtonSearch1);
            this.GroupBox2.Controls.Add(this.ComboBoxSearch1);
            this.GroupBox2.Controls.Add(this.TextBoxSearch1);
            this.GroupBox2.Controls.Add(this.LabelEnter);
            this.GroupBox2.Controls.Add(this.LabelSearchBy);
            this.GroupBox2.Location = new System.Drawing.Point(510, 23);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(278, 181);
            this.GroupBox2.TabIndex = 7;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Search User";
            // 
            // ButtonExit
            // 
            this.ButtonExit.Location = new System.Drawing.Point(174, 152);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit.TabIndex = 17;
            this.ButtonExit.Text = "&Exit";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(174, 40);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 15;
            this.button6.Text = "&List All";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.ButtonList_Click);
            // 
            // ButtonSearch1
            // 
            this.ButtonSearch1.Location = new System.Drawing.Point(174, 105);
            this.ButtonSearch1.Name = "ButtonSearch1";
            this.ButtonSearch1.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch1.TabIndex = 4;
            this.ButtonSearch1.Text = "Search";
            this.ButtonSearch1.UseVisualStyleBackColor = true;
            this.ButtonSearch1.Click += new System.EventHandler(this.ButtonSearch_Click);
            // 
            // ComboBoxSearch1
            // 
            this.ComboBoxSearch1.FormattingEnabled = true;
            this.ComboBoxSearch1.Location = new System.Drawing.Point(30, 42);
            this.ComboBoxSearch1.Name = "ComboBoxSearch1";
            this.ComboBoxSearch1.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxSearch1.TabIndex = 3;
            // 
            // TextBoxSearch1
            // 
            this.TextBoxSearch1.Location = new System.Drawing.Point(30, 107);
            this.TextBoxSearch1.Name = "TextBoxSearch1";
            this.TextBoxSearch1.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch1.TabIndex = 2;
            // 
            // LabelEnter
            // 
            this.LabelEnter.AutoSize = true;
            this.LabelEnter.Location = new System.Drawing.Point(30, 78);
            this.LabelEnter.Name = "LabelEnter";
            this.LabelEnter.Size = new System.Drawing.Size(188, 13);
            this.LabelEnter.TabIndex = 1;
            this.LabelEnter.Text = "Please Enter The keyword for search :";
            // 
            // LabelSearchBy
            // 
            this.LabelSearchBy.AutoSize = true;
            this.LabelSearchBy.Location = new System.Drawing.Point(30, 25);
            this.LabelSearchBy.Name = "LabelSearchBy";
            this.LabelSearchBy.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy.TabIndex = 0;
            this.LabelSearchBy.Text = "Search By";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.TextBoxPassword);
            this.GroupBox1.Controls.Add(this.ButtonReset);
            this.GroupBox1.Controls.Add(this.LabelPassword);
            this.GroupBox1.Controls.Add(this.ButtonDelete1);
            this.GroupBox1.Controls.Add(this.TextBoxLoginId);
            this.GroupBox1.Controls.Add(this.ButtonUpdate1);
            this.GroupBox1.Controls.Add(this.TextBoxDepartment);
            this.GroupBox1.Controls.Add(this.ButtonSave1);
            this.GroupBox1.Controls.Add(this.TextBoxLastName);
            this.GroupBox1.Controls.Add(this.TextBoxUserId);
            this.GroupBox1.Controls.Add(this.TextBoxFirstName);
            this.GroupBox1.Controls.Add(this.LabelUserId);
            this.GroupBox1.Controls.Add(this.LabelLoginId);
            this.GroupBox1.Controls.Add(this.LabelFirstName);
            this.GroupBox1.Controls.Add(this.LabelDepartment);
            this.GroupBox1.Controls.Add(this.LabelLastName);
            this.GroupBox1.Controls.Add(this.LabelDigits);
            this.GroupBox1.Location = new System.Drawing.Point(16, 23);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(475, 181);
            this.GroupBox1.TabIndex = 6;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "User Information";
            // 
            // TextBoxPassword
            // 
            this.TextBoxPassword.Location = new System.Drawing.Point(259, 130);
            this.TextBoxPassword.Name = "TextBoxPassword";
            this.TextBoxPassword.Size = new System.Drawing.Size(104, 20);
            this.TextBoxPassword.TabIndex = 29;
            // 
            // ButtonReset
            // 
            this.ButtonReset.Location = new System.Drawing.Point(386, 142);
            this.ButtonReset.Name = "ButtonReset";
            this.ButtonReset.Size = new System.Drawing.Size(75, 23);
            this.ButtonReset.TabIndex = 16;
            this.ButtonReset.Text = "&Reset";
            this.ButtonReset.UseVisualStyleBackColor = true;
            this.ButtonReset.Click += new System.EventHandler(this.ButtonReset_Click);
            // 
            // LabelPassword
            // 
            this.LabelPassword.AutoSize = true;
            this.LabelPassword.Location = new System.Drawing.Point(278, 113);
            this.LabelPassword.Name = "LabelPassword";
            this.LabelPassword.Size = new System.Drawing.Size(53, 13);
            this.LabelPassword.TabIndex = 28;
            this.LabelPassword.Text = "Password";
            // 
            // ButtonDelete1
            // 
            this.ButtonDelete1.Location = new System.Drawing.Point(386, 84);
            this.ButtonDelete1.Name = "ButtonDelete1";
            this.ButtonDelete1.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete1.TabIndex = 13;
            this.ButtonDelete1.Text = "&Delete";
            this.ButtonDelete1.UseVisualStyleBackColor = true;
            this.ButtonDelete1.Click += new System.EventHandler(this.ButtonDelete_Click);
            // 
            // TextBoxLoginId
            // 
            this.TextBoxLoginId.Location = new System.Drawing.Point(142, 130);
            this.TextBoxLoginId.Name = "TextBoxLoginId";
            this.TextBoxLoginId.Size = new System.Drawing.Size(104, 20);
            this.TextBoxLoginId.TabIndex = 27;
            // 
            // ButtonUpdate1
            // 
            this.ButtonUpdate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate1.Location = new System.Drawing.Point(386, 53);
            this.ButtonUpdate1.Name = "ButtonUpdate1";
            this.ButtonUpdate1.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate1.TabIndex = 12;
            this.ButtonUpdate1.Text = "&Update";
            this.ButtonUpdate1.UseVisualStyleBackColor = true;
            this.ButtonUpdate1.Click += new System.EventHandler(this.ButtonUpdate_Click);
            // 
            // TextBoxDepartment
            // 
            this.TextBoxDepartment.Location = new System.Drawing.Point(21, 130);
            this.TextBoxDepartment.Name = "TextBoxDepartment";
            this.TextBoxDepartment.Size = new System.Drawing.Size(100, 20);
            this.TextBoxDepartment.TabIndex = 26;
            // 
            // ButtonSave1
            // 
            this.ButtonSave1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave1.Location = new System.Drawing.Point(386, 21);
            this.ButtonSave1.Name = "ButtonSave1";
            this.ButtonSave1.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave1.TabIndex = 11;
            this.ButtonSave1.Text = "&Save";
            this.ButtonSave1.UseVisualStyleBackColor = true;
            this.ButtonSave1.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // TextBoxLastName
            // 
            this.TextBoxLastName.Location = new System.Drawing.Point(263, 57);
            this.TextBoxLastName.Name = "TextBoxLastName";
            this.TextBoxLastName.Size = new System.Drawing.Size(100, 20);
            this.TextBoxLastName.TabIndex = 25;
            // 
            // TextBoxUserId
            // 
            this.TextBoxUserId.Location = new System.Drawing.Point(21, 55);
            this.TextBoxUserId.Name = "TextBoxUserId";
            this.TextBoxUserId.Size = new System.Drawing.Size(100, 20);
            this.TextBoxUserId.TabIndex = 18;
            // 
            // TextBoxFirstName
            // 
            this.TextBoxFirstName.Location = new System.Drawing.Point(143, 56);
            this.TextBoxFirstName.Name = "TextBoxFirstName";
            this.TextBoxFirstName.Size = new System.Drawing.Size(100, 20);
            this.TextBoxFirstName.TabIndex = 24;
            // 
            // LabelUserId
            // 
            this.LabelUserId.AutoSize = true;
            this.LabelUserId.Location = new System.Drawing.Point(41, 31);
            this.LabelUserId.Name = "LabelUserId";
            this.LabelUserId.Size = new System.Drawing.Size(43, 13);
            this.LabelUserId.TabIndex = 17;
            this.LabelUserId.Text = "User ID";
            // 
            // LabelLoginId
            // 
            this.LabelLoginId.AutoSize = true;
            this.LabelLoginId.Location = new System.Drawing.Point(166, 113);
            this.LabelLoginId.Name = "LabelLoginId";
            this.LabelLoginId.Size = new System.Drawing.Size(47, 13);
            this.LabelLoginId.TabIndex = 23;
            this.LabelLoginId.Text = "Login ID";
            // 
            // LabelFirstName
            // 
            this.LabelFirstName.AutoSize = true;
            this.LabelFirstName.Location = new System.Drawing.Point(166, 32);
            this.LabelFirstName.Name = "LabelFirstName";
            this.LabelFirstName.Size = new System.Drawing.Size(57, 13);
            this.LabelFirstName.TabIndex = 19;
            this.LabelFirstName.Text = "First Name";
            // 
            // LabelDepartment
            // 
            this.LabelDepartment.AutoSize = true;
            this.LabelDepartment.Location = new System.Drawing.Point(36, 111);
            this.LabelDepartment.Name = "LabelDepartment";
            this.LabelDepartment.Size = new System.Drawing.Size(62, 13);
            this.LabelDepartment.TabIndex = 22;
            this.LabelDepartment.Text = "Department";
            // 
            // LabelLastName
            // 
            this.LabelLastName.AutoSize = true;
            this.LabelLastName.Location = new System.Drawing.Point(278, 32);
            this.LabelLastName.Name = "LabelLastName";
            this.LabelLastName.Size = new System.Drawing.Size(58, 13);
            this.LabelLastName.TabIndex = 20;
            this.LabelLastName.Text = "Last Name";
            // 
            // LabelDigits
            // 
            this.LabelDigits.AutoSize = true;
            this.LabelDigits.Location = new System.Drawing.Point(41, 78);
            this.LabelDigits.Name = "LabelDigits";
            this.LabelDigits.Size = new System.Drawing.Size(51, 13);
            this.LabelDigits.TabIndex = 21;
            this.LabelDigits.Text = "( 3 Digits)";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.listView2);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(814, 387);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "EmployeeControl";
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView2.Location = new System.Drawing.Point(21, 203);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(772, 160);
            this.listView2.TabIndex = 11;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Employee ID";
            this.columnHeader2.Width = 135;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "First Name";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 127;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Last Name";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 135;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Phone Number";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 193;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Email";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 125;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(515, 24);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(278, 161);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search Employee";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(184, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(40, 48);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(40, 113);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(138, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please Enter The Information :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Search By";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TextBoxEmail);
            this.groupBox4.Controls.Add(this.TextBoxPN);
            this.groupBox4.Controls.Add(this.TextBoxLN);
            this.groupBox4.Controls.Add(this.TextBoxFN);
            this.groupBox4.Controls.Add(this.LabelEmail);
            this.groupBox4.Controls.Add(this.LabelPN);
            this.groupBox4.Controls.Add(this.Label3Digits);
            this.groupBox4.Controls.Add(this.LabelLN);
            this.groupBox4.Controls.Add(this.LabelFN);
            this.groupBox4.Controls.Add(this.TextBoxID);
            this.groupBox4.Controls.Add(this.LabelID);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.Button5);
            this.groupBox4.Location = new System.Drawing.Point(21, 24);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(475, 161);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Employee Information";
            // 
            // TextBoxEmail
            // 
            this.TextBoxEmail.Location = new System.Drawing.Point(186, 124);
            this.TextBoxEmail.Name = "TextBoxEmail";
            this.TextBoxEmail.Size = new System.Drawing.Size(177, 20);
            this.TextBoxEmail.TabIndex = 25;
            // 
            // TextBoxPN
            // 
            this.TextBoxPN.Location = new System.Drawing.Point(21, 124);
            this.TextBoxPN.Name = "TextBoxPN";
            this.TextBoxPN.Size = new System.Drawing.Size(146, 20);
            this.TextBoxPN.TabIndex = 24;
            // 
            // TextBoxLN
            // 
            this.TextBoxLN.Location = new System.Drawing.Point(263, 51);
            this.TextBoxLN.Name = "TextBoxLN";
            this.TextBoxLN.Size = new System.Drawing.Size(100, 20);
            this.TextBoxLN.TabIndex = 23;
            // 
            // TextBoxFN
            // 
            this.TextBoxFN.Location = new System.Drawing.Point(143, 50);
            this.TextBoxFN.Name = "TextBoxFN";
            this.TextBoxFN.Size = new System.Drawing.Size(100, 20);
            this.TextBoxFN.TabIndex = 22;
            // 
            // LabelEmail
            // 
            this.LabelEmail.AutoSize = true;
            this.LabelEmail.Location = new System.Drawing.Point(224, 107);
            this.LabelEmail.Name = "LabelEmail";
            this.LabelEmail.Size = new System.Drawing.Size(32, 13);
            this.LabelEmail.TabIndex = 21;
            this.LabelEmail.Text = "Email";
            // 
            // LabelPN
            // 
            this.LabelPN.AutoSize = true;
            this.LabelPN.Location = new System.Drawing.Point(36, 107);
            this.LabelPN.Name = "LabelPN";
            this.LabelPN.Size = new System.Drawing.Size(78, 13);
            this.LabelPN.TabIndex = 20;
            this.LabelPN.Text = "Phone Number";
            // 
            // Label3Digits
            // 
            this.Label3Digits.AutoSize = true;
            this.Label3Digits.Location = new System.Drawing.Point(36, 74);
            this.Label3Digits.Name = "Label3Digits";
            this.Label3Digits.Size = new System.Drawing.Size(51, 13);
            this.Label3Digits.TabIndex = 19;
            this.Label3Digits.Text = "( 3 Digits)";
            // 
            // LabelLN
            // 
            this.LabelLN.AutoSize = true;
            this.LabelLN.Location = new System.Drawing.Point(273, 26);
            this.LabelLN.Name = "LabelLN";
            this.LabelLN.Size = new System.Drawing.Size(58, 13);
            this.LabelLN.TabIndex = 18;
            this.LabelLN.Text = "Last Name";
            // 
            // LabelFN
            // 
            this.LabelFN.AutoSize = true;
            this.LabelFN.Location = new System.Drawing.Point(166, 26);
            this.LabelFN.Name = "LabelFN";
            this.LabelFN.Size = new System.Drawing.Size(57, 13);
            this.LabelFN.TabIndex = 17;
            this.LabelFN.Text = "First Name";
            // 
            // TextBoxID
            // 
            this.TextBoxID.Location = new System.Drawing.Point(21, 51);
            this.TextBoxID.Name = "TextBoxID";
            this.TextBoxID.Size = new System.Drawing.Size(100, 20);
            this.TextBoxID.TabIndex = 16;
            // 
            // LabelID
            // 
            this.LabelID.AutoSize = true;
            this.LabelID.Location = new System.Drawing.Point(36, 26);
            this.LabelID.Name = "LabelID";
            this.LabelID.Size = new System.Drawing.Size(67, 13);
            this.LabelID.TabIndex = 15;
            this.LabelID.Text = "Employee ID";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(386, 126);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "&List";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(386, 94);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "&Delete";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(386, 53);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 12;
            this.button4.Text = "&Update";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // Button5
            // 
            this.Button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button5.Location = new System.Drawing.Point(386, 21);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(75, 23);
            this.Button5.TabIndex = 11;
            this.Button5.Text = "&Save";
            this.Button5.UseVisualStyleBackColor = true;
            // 
            // ButtonCP1
            // 
            this.ButtonCP1.Location = new System.Drawing.Point(33, 152);
            this.ButtonCP1.Name = "ButtonCP1";
            this.ButtonCP1.Size = new System.Drawing.Size(124, 23);
            this.ButtonCP1.TabIndex = 18;
            this.ButtonCP1.Text = "&Change Password";
            this.ButtonCP1.UseVisualStyleBackColor = true;
            this.ButtonCP1.Click += new System.EventHandler(this.ButtonCP1_Click);
            // 
            // Form2Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(880, 450);
            this.Controls.Add(this.TabControl1);
            this.Name = "Form2Manager";
            this.Text = "FormManager";
            this.Load += new System.EventHandler(this.FormManager_Load);
            this.TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListView ListView1;
        private System.Windows.Forms.ColumnHeader User_ID;
        private System.Windows.Forms.ColumnHeader First_Name;
        private System.Windows.Forms.ColumnHeader Last_Name;
        private System.Windows.Forms.ColumnHeader Department;
        private System.Windows.Forms.ColumnHeader Login_ID;
        private System.Windows.Forms.ColumnHeader Password;
        private System.Windows.Forms.GroupBox GroupBox2;
        private System.Windows.Forms.Button ButtonSearch1;
        private System.Windows.Forms.ComboBox ComboBoxSearch1;
        private System.Windows.Forms.TextBox TextBoxSearch1;
        private System.Windows.Forms.Label LabelEnter;
        private System.Windows.Forms.Label LabelSearchBy;
        private System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.TextBox TextBoxPassword;
        private System.Windows.Forms.Label LabelPassword;
        private System.Windows.Forms.Button ButtonDelete1;
        private System.Windows.Forms.TextBox TextBoxLoginId;
        private System.Windows.Forms.Button ButtonUpdate1;
        private System.Windows.Forms.TextBox TextBoxDepartment;
        private System.Windows.Forms.Button ButtonSave1;
        private System.Windows.Forms.TextBox TextBoxLastName;
        private System.Windows.Forms.TextBox TextBoxUserId;
        private System.Windows.Forms.TextBox TextBoxFirstName;
        private System.Windows.Forms.Label LabelUserId;
        private System.Windows.Forms.Label LabelLoginId;
        private System.Windows.Forms.Label LabelFirstName;
        private System.Windows.Forms.Label LabelDepartment;
        private System.Windows.Forms.Label LabelLastName;
        private System.Windows.Forms.Label LabelDigits;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox TextBoxEmail;
        private System.Windows.Forms.TextBox TextBoxPN;
        private System.Windows.Forms.TextBox TextBoxLN;
        private System.Windows.Forms.TextBox TextBoxFN;
        private System.Windows.Forms.Label LabelEmail;
        private System.Windows.Forms.Label LabelPN;
        private System.Windows.Forms.Label Label3Digits;
        private System.Windows.Forms.Label LabelLN;
        private System.Windows.Forms.Label LabelFN;
        private System.Windows.Forms.TextBox TextBoxID;
        private System.Windows.Forms.Label LabelID;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Button ButtonReset;
        private System.Windows.Forms.Button ButtonCP1;
    }
}