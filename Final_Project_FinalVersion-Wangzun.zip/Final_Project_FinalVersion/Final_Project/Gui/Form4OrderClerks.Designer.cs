﻿namespace Final_Project.Gui
{
    partial class Form4OrderClerks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBoxOrderDate = new System.Windows.Forms.TextBox();
            this.TextBoxPayment = new System.Windows.Forms.TextBox();
            this.LabelOrderDate = new System.Windows.Forms.Label();
            this.LabelPayment = new System.Windows.Forms.Label();
            this.TextBoxTotalPrice = new System.Windows.Forms.TextBox();
            this.LabelTotalPrice = new System.Windows.Forms.Label();
            this.ButtonList3 = new System.Windows.Forms.Button();
            this.ButtonDelete3 = new System.Windows.Forms.Button();
            this.ButtonUpdate3 = new System.Windows.Forms.Button();
            this.ButtonSave3 = new System.Windows.Forms.Button();
            this.TextBoxUnitPrice = new System.Windows.Forms.TextBox();
            this.TextBoxQuantity = new System.Windows.Forms.TextBox();
            this.TextBoxISBN3 = new System.Windows.Forms.TextBox();
            this.TextBoxCN3 = new System.Windows.Forms.TextBox();
            this.LabelUnitPrice = new System.Windows.Forms.Label();
            this.LabelQuantity = new System.Windows.Forms.Label();
            this.Label4Digits3 = new System.Windows.Forms.Label();
            this.LabelISBN3 = new System.Windows.Forms.Label();
            this.LabelCN3 = new System.Windows.Forms.Label();
            this.TextBoxID3 = new System.Windows.Forms.TextBox();
            this.LabelID3 = new System.Windows.Forms.Label();
            this.ButtonSearch3 = new System.Windows.Forms.Button();
            this.ComboBox3 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch3 = new System.Windows.Forms.TextBox();
            this.LabelEnter3 = new System.Windows.Forms.Label();
            this.Take_Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Payment = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TotalPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UnitPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Quantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ISBN = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Customer_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Order_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.ButtonCP3 = new System.Windows.Forms.Button();
            this.LabelSearchBy3 = new System.Windows.Forms.Label();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.ButtonReset3 = new System.Windows.Forms.Button();
            this.TextBoxTakeType = new System.Windows.Forms.TextBox();
            this.LabelTakeType = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Order_Date = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.GroupBox6.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // TextBoxOrderDate
            // 
            this.TextBoxOrderDate.Location = new System.Drawing.Point(227, 186);
            this.TextBoxOrderDate.Name = "TextBoxOrderDate";
            this.TextBoxOrderDate.Size = new System.Drawing.Size(125, 20);
            this.TextBoxOrderDate.TabIndex = 20;
            // 
            // TextBoxPayment
            // 
            this.TextBoxPayment.Location = new System.Drawing.Point(19, 186);
            this.TextBoxPayment.Name = "TextBoxPayment";
            this.TextBoxPayment.Size = new System.Drawing.Size(100, 20);
            this.TextBoxPayment.TabIndex = 19;
            // 
            // LabelOrderDate
            // 
            this.LabelOrderDate.AutoSize = true;
            this.LabelOrderDate.Location = new System.Drawing.Point(268, 168);
            this.LabelOrderDate.Name = "LabelOrderDate";
            this.LabelOrderDate.Size = new System.Drawing.Size(59, 13);
            this.LabelOrderDate.TabIndex = 18;
            this.LabelOrderDate.Text = "Order Date";
            // 
            // LabelPayment
            // 
            this.LabelPayment.AutoSize = true;
            this.LabelPayment.Location = new System.Drawing.Point(34, 169);
            this.LabelPayment.Name = "LabelPayment";
            this.LabelPayment.Size = new System.Drawing.Size(48, 13);
            this.LabelPayment.TabIndex = 17;
            this.LabelPayment.Text = "Payment";
            // 
            // TextBoxTotalPrice
            // 
            this.TextBoxTotalPrice.Location = new System.Drawing.Point(252, 126);
            this.TextBoxTotalPrice.Name = "TextBoxTotalPrice";
            this.TextBoxTotalPrice.Size = new System.Drawing.Size(100, 20);
            this.TextBoxTotalPrice.TabIndex = 16;
            this.TextBoxTotalPrice.Click += new System.EventHandler(this.TextBoxTotalPrice_Click);
            // 
            // LabelTotalPrice
            // 
            this.LabelTotalPrice.AutoSize = true;
            this.LabelTotalPrice.Location = new System.Drawing.Point(272, 109);
            this.LabelTotalPrice.Name = "LabelTotalPrice";
            this.LabelTotalPrice.Size = new System.Drawing.Size(55, 13);
            this.LabelTotalPrice.TabIndex = 15;
            this.LabelTotalPrice.Text = "TotalPrice";
            // 
            // ButtonList3
            // 
            this.ButtonList3.Location = new System.Drawing.Point(37, 153);
            this.ButtonList3.Name = "ButtonList3";
            this.ButtonList3.Size = new System.Drawing.Size(75, 23);
            this.ButtonList3.TabIndex = 14;
            this.ButtonList3.Text = "&List All";
            this.ButtonList3.UseVisualStyleBackColor = true;
            this.ButtonList3.Click += new System.EventHandler(this.ButtonList3_Click);
            // 
            // ButtonDelete3
            // 
            this.ButtonDelete3.Location = new System.Drawing.Point(389, 108);
            this.ButtonDelete3.Name = "ButtonDelete3";
            this.ButtonDelete3.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete3.TabIndex = 13;
            this.ButtonDelete3.Text = "&Delete";
            this.ButtonDelete3.UseVisualStyleBackColor = true;
            this.ButtonDelete3.Click += new System.EventHandler(this.ButtonDelete3_Click);
            // 
            // ButtonUpdate3
            // 
            this.ButtonUpdate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate3.Location = new System.Drawing.Point(389, 67);
            this.ButtonUpdate3.Name = "ButtonUpdate3";
            this.ButtonUpdate3.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate3.TabIndex = 12;
            this.ButtonUpdate3.Text = "&Update";
            this.ButtonUpdate3.UseVisualStyleBackColor = true;
            this.ButtonUpdate3.Click += new System.EventHandler(this.ButtonUpdate3_Click);
            // 
            // ButtonSave3
            // 
            this.ButtonSave3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave3.Location = new System.Drawing.Point(389, 26);
            this.ButtonSave3.Name = "ButtonSave3";
            this.ButtonSave3.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave3.TabIndex = 11;
            this.ButtonSave3.Text = "&Save";
            this.ButtonSave3.UseVisualStyleBackColor = true;
            this.ButtonSave3.Click += new System.EventHandler(this.ButtonSave3_Click);
            // 
            // TextBoxUnitPrice
            // 
            this.TextBoxUnitPrice.Location = new System.Drawing.Point(137, 126);
            this.TextBoxUnitPrice.Name = "TextBoxUnitPrice";
            this.TextBoxUnitPrice.Size = new System.Drawing.Size(100, 20);
            this.TextBoxUnitPrice.TabIndex = 10;
            // 
            // TextBoxQuantity
            // 
            this.TextBoxQuantity.Location = new System.Drawing.Point(19, 126);
            this.TextBoxQuantity.Name = "TextBoxQuantity";
            this.TextBoxQuantity.Size = new System.Drawing.Size(100, 20);
            this.TextBoxQuantity.TabIndex = 9;
            // 
            // TextBoxISBN3
            // 
            this.TextBoxISBN3.Location = new System.Drawing.Point(252, 53);
            this.TextBoxISBN3.Name = "TextBoxISBN3";
            this.TextBoxISBN3.Size = new System.Drawing.Size(100, 20);
            this.TextBoxISBN3.TabIndex = 8;
            // 
            // TextBoxCN3
            // 
            this.TextBoxCN3.Location = new System.Drawing.Point(135, 53);
            this.TextBoxCN3.Name = "TextBoxCN3";
            this.TextBoxCN3.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCN3.TabIndex = 7;
            // 
            // LabelUnitPrice
            // 
            this.LabelUnitPrice.AutoSize = true;
            this.LabelUnitPrice.Location = new System.Drawing.Point(157, 109);
            this.LabelUnitPrice.Name = "LabelUnitPrice";
            this.LabelUnitPrice.Size = new System.Drawing.Size(50, 13);
            this.LabelUnitPrice.TabIndex = 6;
            this.LabelUnitPrice.Text = "UnitPrice";
            // 
            // LabelQuantity
            // 
            this.LabelQuantity.AutoSize = true;
            this.LabelQuantity.Location = new System.Drawing.Point(45, 109);
            this.LabelQuantity.Name = "LabelQuantity";
            this.LabelQuantity.Size = new System.Drawing.Size(46, 13);
            this.LabelQuantity.TabIndex = 5;
            this.LabelQuantity.Text = "Quantity";
            // 
            // Label4Digits3
            // 
            this.Label4Digits3.AutoSize = true;
            this.Label4Digits3.Location = new System.Drawing.Point(34, 80);
            this.Label4Digits3.Name = "Label4Digits3";
            this.Label4Digits3.Size = new System.Drawing.Size(51, 13);
            this.Label4Digits3.TabIndex = 4;
            this.Label4Digits3.Text = "( 4 Digits)";
            // 
            // LabelISBN3
            // 
            this.LabelISBN3.AutoSize = true;
            this.LabelISBN3.Location = new System.Drawing.Point(276, 32);
            this.LabelISBN3.Name = "LabelISBN3";
            this.LabelISBN3.Size = new System.Drawing.Size(32, 13);
            this.LabelISBN3.TabIndex = 3;
            this.LabelISBN3.Text = "ISBN";
            // 
            // LabelCN3
            // 
            this.LabelCN3.AutoSize = true;
            this.LabelCN3.Location = new System.Drawing.Point(141, 32);
            this.LabelCN3.Name = "LabelCN3";
            this.LabelCN3.Size = new System.Drawing.Size(65, 13);
            this.LabelCN3.TabIndex = 2;
            this.LabelCN3.Text = "Customer ID";
            // 
            // TextBoxID3
            // 
            this.TextBoxID3.Location = new System.Drawing.Point(19, 53);
            this.TextBoxID3.Name = "TextBoxID3";
            this.TextBoxID3.Size = new System.Drawing.Size(100, 20);
            this.TextBoxID3.TabIndex = 1;
            // 
            // LabelID3
            // 
            this.LabelID3.AutoSize = true;
            this.LabelID3.Location = new System.Drawing.Point(31, 32);
            this.LabelID3.Name = "LabelID3";
            this.LabelID3.Size = new System.Drawing.Size(47, 13);
            this.LabelID3.TabIndex = 0;
            this.LabelID3.Text = "Order ID";
            // 
            // ButtonSearch3
            // 
            this.ButtonSearch3.Location = new System.Drawing.Point(131, 153);
            this.ButtonSearch3.Name = "ButtonSearch3";
            this.ButtonSearch3.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch3.TabIndex = 4;
            this.ButtonSearch3.Text = "&Search";
            this.ButtonSearch3.UseVisualStyleBackColor = true;
            this.ButtonSearch3.Click += new System.EventHandler(this.ButtonSearch3_Click);
            // 
            // ComboBox3
            // 
            this.ComboBox3.FormattingEnabled = true;
            this.ComboBox3.Location = new System.Drawing.Point(48, 48);
            this.ComboBox3.Name = "ComboBox3";
            this.ComboBox3.Size = new System.Drawing.Size(121, 21);
            this.ComboBox3.TabIndex = 3;
            // 
            // TextBoxSearch3
            // 
            this.TextBoxSearch3.Location = new System.Drawing.Point(48, 110);
            this.TextBoxSearch3.Name = "TextBoxSearch3";
            this.TextBoxSearch3.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch3.TabIndex = 2;
            // 
            // LabelEnter3
            // 
            this.LabelEnter3.AutoSize = true;
            this.LabelEnter3.Location = new System.Drawing.Point(24, 83);
            this.LabelEnter3.Name = "LabelEnter3";
            this.LabelEnter3.Size = new System.Drawing.Size(185, 13);
            this.LabelEnter3.TabIndex = 1;
            this.LabelEnter3.Text = "Please Enter The keyword for search:";
            // 
            // Take_Type
            // 
            this.Take_Type.Text = "Take Type";
            this.Take_Type.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Take_Type.Width = 120;
            // 
            // Payment
            // 
            this.Payment.Text = "Payment";
            this.Payment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Payment.Width = 104;
            // 
            // TotalPrice
            // 
            this.TotalPrice.Text = "TotalPrice";
            this.TotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TotalPrice.Width = 80;
            // 
            // UnitPrice
            // 
            this.UnitPrice.Text = "UnitPrice";
            this.UnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UnitPrice.Width = 81;
            // 
            // Quantity
            // 
            this.Quantity.Text = "Quantity";
            this.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Quantity.Width = 78;
            // 
            // ISBN
            // 
            this.ISBN.Text = "ISBN";
            this.ISBN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ISBN.Width = 111;
            // 
            // Customer_ID
            // 
            this.Customer_ID.Text = "Customer ID";
            this.Customer_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Customer_ID.Width = 98;
            // 
            // Order_ID
            // 
            this.Order_ID.Text = "Order ID";
            this.Order_ID.Width = 75;
            // 
            // GroupBox6
            // 
            this.GroupBox6.BackColor = System.Drawing.Color.Silver;
            this.GroupBox6.Controls.Add(this.ButtonCP3);
            this.GroupBox6.Controls.Add(this.ButtonSearch3);
            this.GroupBox6.Controls.Add(this.ComboBox3);
            this.GroupBox6.Controls.Add(this.TextBoxSearch3);
            this.GroupBox6.Controls.Add(this.LabelEnter3);
            this.GroupBox6.Controls.Add(this.LabelSearchBy3);
            this.GroupBox6.Controls.Add(this.ButtonList3);
            this.GroupBox6.Location = new System.Drawing.Point(544, 21);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(236, 224);
            this.GroupBox6.TabIndex = 10;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Search Order";
            // 
            // ButtonCP3
            // 
            this.ButtonCP3.Location = new System.Drawing.Point(62, 195);
            this.ButtonCP3.Name = "ButtonCP3";
            this.ButtonCP3.Size = new System.Drawing.Size(124, 23);
            this.ButtonCP3.TabIndex = 19;
            this.ButtonCP3.Text = "&Change Password";
            this.ButtonCP3.UseVisualStyleBackColor = true;
            this.ButtonCP3.Click += new System.EventHandler(this.ButtonCP3_Click);
            // 
            // LabelSearchBy3
            // 
            this.LabelSearchBy3.AutoSize = true;
            this.LabelSearchBy3.Location = new System.Drawing.Point(71, 26);
            this.LabelSearchBy3.Name = "LabelSearchBy3";
            this.LabelSearchBy3.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy3.TabIndex = 0;
            this.LabelSearchBy3.Text = "Search By";
            // 
            // GroupBox5
            // 
            this.GroupBox5.BackColor = System.Drawing.Color.Silver;
            this.GroupBox5.Controls.Add(this.label1);
            this.GroupBox5.Controls.Add(this.ButtonExit);
            this.GroupBox5.Controls.Add(this.ButtonReset3);
            this.GroupBox5.Controls.Add(this.TextBoxTakeType);
            this.GroupBox5.Controls.Add(this.LabelTakeType);
            this.GroupBox5.Controls.Add(this.TextBoxOrderDate);
            this.GroupBox5.Controls.Add(this.TextBoxPayment);
            this.GroupBox5.Controls.Add(this.LabelOrderDate);
            this.GroupBox5.Controls.Add(this.LabelPayment);
            this.GroupBox5.Controls.Add(this.TextBoxTotalPrice);
            this.GroupBox5.Controls.Add(this.LabelTotalPrice);
            this.GroupBox5.Controls.Add(this.ButtonDelete3);
            this.GroupBox5.Controls.Add(this.ButtonUpdate3);
            this.GroupBox5.Controls.Add(this.ButtonSave3);
            this.GroupBox5.Controls.Add(this.TextBoxUnitPrice);
            this.GroupBox5.Controls.Add(this.TextBoxQuantity);
            this.GroupBox5.Controls.Add(this.TextBoxISBN3);
            this.GroupBox5.Controls.Add(this.TextBoxCN3);
            this.GroupBox5.Controls.Add(this.LabelUnitPrice);
            this.GroupBox5.Controls.Add(this.LabelQuantity);
            this.GroupBox5.Controls.Add(this.Label4Digits3);
            this.GroupBox5.Controls.Add(this.LabelISBN3);
            this.GroupBox5.Controls.Add(this.LabelCN3);
            this.GroupBox5.Controls.Add(this.TextBoxID3);
            this.GroupBox5.Controls.Add(this.LabelID3);
            this.GroupBox5.Location = new System.Drawing.Point(23, 21);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(491, 224);
            this.GroupBox5.TabIndex = 9;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Orders Information";
            // 
            // ButtonExit
            // 
            this.ButtonExit.Location = new System.Drawing.Point(389, 191);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit.TabIndex = 24;
            this.ButtonExit.Text = "&Exit";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // ButtonReset3
            // 
            this.ButtonReset3.Location = new System.Drawing.Point(389, 153);
            this.ButtonReset3.Name = "ButtonReset3";
            this.ButtonReset3.Size = new System.Drawing.Size(75, 23);
            this.ButtonReset3.TabIndex = 23;
            this.ButtonReset3.Text = "&Reset";
            this.ButtonReset3.UseVisualStyleBackColor = true;
            this.ButtonReset3.Click += new System.EventHandler(this.ButtonReset3_Click);
            // 
            // TextBoxTakeType
            // 
            this.TextBoxTakeType.Location = new System.Drawing.Point(137, 186);
            this.TextBoxTakeType.Name = "TextBoxTakeType";
            this.TextBoxTakeType.Size = new System.Drawing.Size(70, 20);
            this.TextBoxTakeType.TabIndex = 22;
            // 
            // LabelTakeType
            // 
            this.LabelTakeType.AutoSize = true;
            this.LabelTakeType.Location = new System.Drawing.Point(141, 168);
            this.LabelTakeType.Name = "LabelTakeType";
            this.LabelTakeType.Size = new System.Drawing.Size(56, 13);
            this.LabelTakeType.TabIndex = 21;
            this.LabelTakeType.Text = "TakeType";
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.Silver;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Order_ID,
            this.Customer_ID,
            this.ISBN,
            this.Quantity,
            this.UnitPrice,
            this.TotalPrice,
            this.Payment,
            this.Take_Type,
            this.Order_Date});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(23, 261);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(757, 214);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView1_MouseClick);
            // 
            // Order_Date
            // 
            this.Order_Date.Text = "Order Date";
            this.Order_Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(252, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "YYYY-MM-DD";
            // 
            // Form4OrderClerks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(800, 487);
            this.Controls.Add(this.GroupBox6);
            this.Controls.Add(this.GroupBox5);
            this.Controls.Add(this.listView1);
            this.Name = "Form4OrderClerks";
            this.Text = "FormOrderClerks";
            this.Load += new System.EventHandler(this.FormOrderClerks_Load);
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox TextBoxOrderDate;
        private System.Windows.Forms.TextBox TextBoxPayment;
        private System.Windows.Forms.Label LabelOrderDate;
        private System.Windows.Forms.Label LabelPayment;
        private System.Windows.Forms.TextBox TextBoxTotalPrice;
        private System.Windows.Forms.Label LabelTotalPrice;
        private System.Windows.Forms.Button ButtonList3;
        private System.Windows.Forms.Button ButtonDelete3;
        private System.Windows.Forms.Button ButtonUpdate3;
        private System.Windows.Forms.Button ButtonSave3;
        private System.Windows.Forms.TextBox TextBoxUnitPrice;
        private System.Windows.Forms.TextBox TextBoxQuantity;
        private System.Windows.Forms.TextBox TextBoxISBN3;
        private System.Windows.Forms.TextBox TextBoxCN3;
        private System.Windows.Forms.Label LabelUnitPrice;
        private System.Windows.Forms.Label LabelQuantity;
        private System.Windows.Forms.Label Label4Digits3;
        private System.Windows.Forms.Label LabelISBN3;
        private System.Windows.Forms.Label LabelCN3;
        private System.Windows.Forms.TextBox TextBoxID3;
        private System.Windows.Forms.Label LabelID3;
        private System.Windows.Forms.Button ButtonSearch3;
        private System.Windows.Forms.ComboBox ComboBox3;
        private System.Windows.Forms.TextBox TextBoxSearch3;
        private System.Windows.Forms.Label LabelEnter3;
        private System.Windows.Forms.ColumnHeader Take_Type;
        private System.Windows.Forms.ColumnHeader Payment;
        private System.Windows.Forms.ColumnHeader TotalPrice;
        private System.Windows.Forms.ColumnHeader UnitPrice;
        private System.Windows.Forms.ColumnHeader Quantity;
        private System.Windows.Forms.ColumnHeader ISBN;
        private System.Windows.Forms.ColumnHeader Customer_ID;
        private System.Windows.Forms.ColumnHeader Order_ID;
        private System.Windows.Forms.GroupBox GroupBox6;
        private System.Windows.Forms.Label LabelSearchBy3;
        private System.Windows.Forms.GroupBox GroupBox5;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox TextBoxTakeType;
        private System.Windows.Forms.Label LabelTakeType;
        private System.Windows.Forms.ColumnHeader Order_Date;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Button ButtonReset3;
        private System.Windows.Forms.Button ButtonCP3;
        private System.Windows.Forms.Label label1;
    }
}