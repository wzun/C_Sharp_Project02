﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;


namespace Final_Project.Gui
{
    public partial class Form5Accountant : Form
    {
        public enum SearchBy
        {
            undefined, Invoice_Id, Customer_Id, Order_Id, Invoice_Date
        }

        public Form5Accountant()
        {
            InitializeComponent();
        }

        //---------connect to DB-------
        FinalProjectDBEntities context = new FinalProjectDBEntities();

        //----------Form load---------------
        private void FormAccountant_Load(object sender, EventArgs e)
        {
            foreach (SearchBy type in Enum.GetValues(typeof(SearchBy)))
            {
                this.ComboBox4.Items.Add(type);
            }
            this.ComboBox4.Text = Convert.ToString(ComboBox4.Items[0]);

            listView1.FullRowSelect = true;

            PopulateView();
        }

        // ----------function list data in the listview-----------
        private void PopulateView()
        {
            var invoicelist = from invoice in context.Invoices
                            select invoice;
            listView1.Items.Clear();
            foreach (var invoice in invoicelist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(invoice.Invoice_Id));
                item.SubItems.Add(Convert.ToString(invoice.Customer_Id));
                item.SubItems.Add(Convert.ToString(invoice.Order_Id));
                item.SubItems.Add(Convert.ToString(invoice.Invoice_Date));

                listView1.Items.Add(item);
            }
        }

        // ----------function1 list data in the listview-----------
        private void PopulateView1(Invoice invoice)
        {
            listView1.Items.Clear();

            ListViewItem item = new ListViewItem(Convert.ToString(invoice.Invoice_Id));
            item.SubItems.Add(Convert.ToString(invoice.Customer_Id));
            item.SubItems.Add(Convert.ToString(invoice.Order_Id));
            item.SubItems.Add(Convert.ToString(invoice.Invoice_Date));

            listView1.Items.Add(item);
        }

        // ----------function search by string and list data in the listview-----------
        private void PopulateView2(List<Invoice> listInvoice)
        {
            listView1.Items.Clear();
            foreach (var invoice in listInvoice)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(invoice.Invoice_Id));
                item.SubItems.Add(Convert.ToString(invoice.Customer_Id));
                item.SubItems.Add(Convert.ToString(invoice.Order_Id));
                item.SubItems.Add(Convert.ToString(invoice.Invoice_Date));

                listView1.Items.Add(item);
            }
        }

        //------select listview and put data into the textbox-------
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = listView1.SelectedItems[0];
            TextBoxID4.Text = item.SubItems[0].Text;
            TextBoxCID4.Text = item.SubItems[1].Text;
            TextBoxOrderID4.Text = item.SubItems[2].Text;
            TextBoxInvoiceDate.Text = item.SubItems[3].Text;

        }

        //--------------function empty all the input---------------
        public void Empty_Input()
        {
            TextBoxID4.Text = "";
            TextBoxCID4.Text = "";
            TextBoxOrderID4.Text = "";
            TextBoxInvoiceDate.Text = "";
        }



        //----------list------------
        private void ButtonList4_Click(object sender, EventArgs e)
        {
            PopulateView();
        }

        //----------save-------------
        private void ButtonSave4_Click(object sender, EventArgs e)
        {
            Invoice invoice = new Invoice();

            int searchInvoice_Id = Convert.ToInt32(TextBoxID4.Text.Trim());
            Invoice invoice1 = context.Invoices.Find(searchInvoice_Id);
            if (invoice1 != null)
            {
                MessageBox.Show("Dupicated Invoice Id", "Error");
                TextBoxID4.Clear();
                TextBoxID4.Focus();
                return;
            }
            else
            {
                invoice.Invoice_Id = Convert.ToInt32(TextBoxID4.Text.Trim());
            }

            invoice.Customer_Id = Convert.ToInt32(TextBoxCID4.Text.Trim());
            invoice.Order_Id = Convert.ToInt32(TextBoxOrderID4.Text.Trim());
            invoice.Invoice_Date = Convert.ToDateTime(TextBoxInvoiceDate.Text.Trim());
           
            context.Invoices.Add(invoice);
            context.SaveChanges();

            PopulateView();
            MessageBox.Show("Invoice saved successfully!");
            Empty_Input();
        }

        //----------update-----------
        private void ButtonUpdate4_Click(object sender, EventArgs e)
        {
            if (TextBoxID4.Text == "" || TextBoxCID4.Text == "" || TextBoxOrderID4.Text == ""
                || TextBoxInvoiceDate.Text == "" )
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int invoiceId = Convert.ToInt32(TextBoxID4.Text.Trim());
                Invoice invoice1 = context.Invoices.Find(invoiceId);
                if (invoice1 != null)
                {
                    invoice1.Invoice_Id = Convert.ToInt32(TextBoxID4.Text.Trim());
                    invoice1.Customer_Id = Convert.ToInt32(TextBoxCID4.Text.Trim());
                    invoice1.Order_Id = Convert.ToInt32(TextBoxOrderID4.Text.Trim());
                    invoice1.Invoice_Date = Convert.ToDateTime(TextBoxInvoiceDate.Text.Trim());                   

                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Invoice update successfully!");
                }
                else
                {
                    TextBoxID4.Enabled = true;
                    MessageBox.Show("Invoice not Found!");
                }
            }
            Empty_Input();
        }

        //----------delete-----------
        private void ButtonDelete4_Click(object sender, EventArgs e)
        {
            if (TextBoxID4.Text == "" || TextBoxCID4.Text == "" || TextBoxOrderID4.Text == ""
                || TextBoxInvoiceDate.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int invoiceId = Convert.ToInt32(TextBoxID4.Text.Trim());
                Invoice invoice1 = context.Invoices.Find(invoiceId);
                if (invoice1 != null)
                {
                    context.Invoices.Remove(invoice1);

                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Invoice update successfully!");
                }
                else
                {
                    TextBoxID4.Enabled = true;
                    MessageBox.Show("Invoice not Found!");
                }
            }
            Empty_Input();
        }

        //----------search-----------
        private void ButtonSearch4_Click(object sender, EventArgs e)
        {
            if (ComboBox4.Text == Convert.ToString(ComboBox4.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ComboBox4.Text == Convert.ToString(ComboBox4.Items[1]))
                {
                    int invoiceId = Convert.ToInt32(TextBoxSearch4.Text.Trim());
                    Invoice invoice1 = context.Invoices.Find(invoiceId);
                    if (invoice1 != null)
                    {
                        PopulateView1(invoice1);
                    }
                    else
                    {
                        MessageBox.Show("Invoice not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch4.Text = "";
                        TextBoxSearch4.Focus();
                    }

                }
                else if (ComboBox4.Text == Convert.ToString(ComboBox4.Items[2]))
                {
                    int invoiceCI = Convert.ToInt32(TextBoxSearch4.Text.Trim());
                    int i = Convert.ToInt32(invoiceCI);
                    var listInvoice = context.Invoices.Where(CI => CI.Customer_Id == i).ToList<Invoice>();

                    if (listInvoice.Count != 0)
                    {
                        PopulateView2(listInvoice);
                    }
                    else
                    {
                        MessageBox.Show("Invoice not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch4.Text = "";
                        TextBoxSearch4.Focus();
                    }
                }
                else if (ComboBox4.Text == Convert.ToString(ComboBox4.Items[3]))
                {
                    int invoiceId = Convert.ToInt32(TextBoxSearch4.Text.Trim());
                    Invoice invoice1 = context.Invoices.Find(invoiceId);
                    if (invoice1 != null)
                    {
                        PopulateView1(invoice1);
                    }
                    else
                    {
                        MessageBox.Show("Invoice not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (ComboBox4.Text == Convert.ToString(ComboBox4.Items[4]))
                {
                    string invoiceID = TextBoxSearch4.Text.Trim();
                    DateTime i = Convert.ToDateTime(invoiceID);
                    var listInvoice = context.Invoices.Where(ID => ID.Invoice_Date == i).ToList<Invoice>();

                    if (listInvoice.Count != 0)
                    {
                        PopulateView2(listInvoice);
                    }
                    else
                    {
                        MessageBox.Show("Invoice not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch4.Text = "";
                        TextBoxSearch4.Focus();
                    }
                }
            }
        }

        //----------reset-----------
        private void ButtonReset3_Click(object sender, EventArgs e)
        {
            TextBoxID4.Text = "";
            TextBoxCID4.Text = "";
            TextBoxOrderID4.Text = "";
            TextBoxInvoiceDate.Text = "";
            TextBoxID4.Focus();
        }

        //----------exit-----------
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("End of application, see you next time !");
            this.Close();
        }

        //----------print-----------
        private void ButtonPrintInvoice_Click(object sender, EventArgs e)
        {
            if (TextBoxID4.Text == "" || TextBoxCID4.Text == "" || TextBoxOrderID4.Text == ""
               || TextBoxInvoiceDate.Text == "")
            {
                MessageBox.Show("print data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (System.IO.StreamWriter file =
                    new System.IO.StreamWriter(@"..//..//..//InvoicePrint.txt", true))
                {
                    file.WriteLine("-------------------------------");
                    file.WriteLine("Invoice ID :" + TextBoxID4.Text);
                    file.WriteLine("Customer ID :" + TextBoxCID4.Text);
                    file.WriteLine("Order ID :" + TextBoxOrderID4.Text);
                    file.WriteLine("Invoice Date :" + TextBoxInvoiceDate.Text);

                    MessageBox.Show("Invoice print to file InvoicePrint.txt successfully!");
                }
                
            }
        }

        private void ButtonCP4_Click(object sender, EventArgs e)
        {
            Form7ChangePassword form7 = new Form7ChangePassword();
            this.Hide();
            form7.ShowDialog();
            this.Close();
        }
    }
}
