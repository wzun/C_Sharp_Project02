﻿namespace Final_Project.Gui
{
    partial class Form5Accountant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.Invoice_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Customer_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Order_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Invoice_Date = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ComboBox4 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch4 = new System.Windows.Forms.TextBox();
            this.LabelEnter4 = new System.Windows.Forms.Label();
            this.ButtonSearch4 = new System.Windows.Forms.Button();
            this.GroupBox8 = new System.Windows.Forms.GroupBox();
            this.ButtonCP4 = new System.Windows.Forms.Button();
            this.ButtonList4 = new System.Windows.Forms.Button();
            this.LabelSearchBy4 = new System.Windows.Forms.Label();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.ButtonReset3 = new System.Windows.Forms.Button();
            this.ButtonPrintInvoice = new System.Windows.Forms.Button();
            this.ButtonDelete4 = new System.Windows.Forms.Button();
            this.ButtonUpdate4 = new System.Windows.Forms.Button();
            this.ButtonSave4 = new System.Windows.Forms.Button();
            this.TextBoxInvoiceDate = new System.Windows.Forms.TextBox();
            this.TextBoxOrderID4 = new System.Windows.Forms.TextBox();
            this.TextBoxCID4 = new System.Windows.Forms.TextBox();
            this.LabelInvoiceDate = new System.Windows.Forms.Label();
            this.LabelOrderID4 = new System.Windows.Forms.Label();
            this.Label4Digits3 = new System.Windows.Forms.Label();
            this.LabelCID4 = new System.Windows.Forms.Label();
            this.TextBoxID4 = new System.Windows.Forms.TextBox();
            this.LabelID4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.GroupBox8.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.Silver;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Invoice_ID,
            this.Customer_ID,
            this.Order_ID,
            this.Invoice_Date});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(21, 246);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(689, 183);
            this.listView1.TabIndex = 14;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView1_MouseClick);
            // 
            // Invoice_ID
            // 
            this.Invoice_ID.Text = "Invoice ID";
            this.Invoice_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Invoice_ID.Width = 73;
            // 
            // Customer_ID
            // 
            this.Customer_ID.Text = "Customer ID";
            this.Customer_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Customer_ID.Width = 99;
            // 
            // Order_ID
            // 
            this.Order_ID.Text = "Order ID";
            this.Order_ID.Width = 73;
            // 
            // Invoice_Date
            // 
            this.Invoice_Date.Text = "Invoice Date";
            this.Invoice_Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Invoice_Date.Width = 101;
            // 
            // ComboBox4
            // 
            this.ComboBox4.FormattingEnabled = true;
            this.ComboBox4.Location = new System.Drawing.Point(48, 41);
            this.ComboBox4.Name = "ComboBox4";
            this.ComboBox4.Size = new System.Drawing.Size(121, 21);
            this.ComboBox4.TabIndex = 3;
            // 
            // TextBoxSearch4
            // 
            this.TextBoxSearch4.Location = new System.Drawing.Point(45, 105);
            this.TextBoxSearch4.Name = "TextBoxSearch4";
            this.TextBoxSearch4.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch4.TabIndex = 2;
            // 
            // LabelEnter4
            // 
            this.LabelEnter4.AutoSize = true;
            this.LabelEnter4.Location = new System.Drawing.Point(42, 80);
            this.LabelEnter4.Name = "LabelEnter4";
            this.LabelEnter4.Size = new System.Drawing.Size(163, 13);
            this.LabelEnter4.TabIndex = 1;
            this.LabelEnter4.Text = "Please Enter keyword for search:";
            // 
            // ButtonSearch4
            // 
            this.ButtonSearch4.Location = new System.Drawing.Point(130, 140);
            this.ButtonSearch4.Name = "ButtonSearch4";
            this.ButtonSearch4.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch4.TabIndex = 4;
            this.ButtonSearch4.Text = "&Search";
            this.ButtonSearch4.UseVisualStyleBackColor = true;
            this.ButtonSearch4.Click += new System.EventHandler(this.ButtonSearch4_Click);
            // 
            // GroupBox8
            // 
            this.GroupBox8.BackColor = System.Drawing.Color.Silver;
            this.GroupBox8.Controls.Add(this.ButtonCP4);
            this.GroupBox8.Controls.Add(this.ButtonSearch4);
            this.GroupBox8.Controls.Add(this.ButtonList4);
            this.GroupBox8.Controls.Add(this.ComboBox4);
            this.GroupBox8.Controls.Add(this.TextBoxSearch4);
            this.GroupBox8.Controls.Add(this.LabelEnter4);
            this.GroupBox8.Controls.Add(this.LabelSearchBy4);
            this.GroupBox8.Location = new System.Drawing.Point(474, 26);
            this.GroupBox8.Name = "GroupBox8";
            this.GroupBox8.Size = new System.Drawing.Size(236, 205);
            this.GroupBox8.TabIndex = 13;
            this.GroupBox8.TabStop = false;
            this.GroupBox8.Text = "Search Invoice";
            // 
            // ButtonCP4
            // 
            this.ButtonCP4.Location = new System.Drawing.Point(48, 177);
            this.ButtonCP4.Name = "ButtonCP4";
            this.ButtonCP4.Size = new System.Drawing.Size(124, 23);
            this.ButtonCP4.TabIndex = 19;
            this.ButtonCP4.Text = "&Change Password";
            this.ButtonCP4.UseVisualStyleBackColor = true;
            this.ButtonCP4.Click += new System.EventHandler(this.ButtonCP4_Click);
            // 
            // ButtonList4
            // 
            this.ButtonList4.Location = new System.Drawing.Point(25, 140);
            this.ButtonList4.Name = "ButtonList4";
            this.ButtonList4.Size = new System.Drawing.Size(75, 23);
            this.ButtonList4.TabIndex = 14;
            this.ButtonList4.Text = "&List All";
            this.ButtonList4.UseVisualStyleBackColor = true;
            this.ButtonList4.Click += new System.EventHandler(this.ButtonList4_Click);
            // 
            // LabelSearchBy4
            // 
            this.LabelSearchBy4.AutoSize = true;
            this.LabelSearchBy4.Location = new System.Drawing.Point(69, 25);
            this.LabelSearchBy4.Name = "LabelSearchBy4";
            this.LabelSearchBy4.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy4.TabIndex = 0;
            this.LabelSearchBy4.Text = "Search By";
            // 
            // GroupBox7
            // 
            this.GroupBox7.BackColor = System.Drawing.Color.Silver;
            this.GroupBox7.Controls.Add(this.label1);
            this.GroupBox7.Controls.Add(this.ButtonExit);
            this.GroupBox7.Controls.Add(this.ButtonReset3);
            this.GroupBox7.Controls.Add(this.ButtonPrintInvoice);
            this.GroupBox7.Controls.Add(this.ButtonDelete4);
            this.GroupBox7.Controls.Add(this.ButtonUpdate4);
            this.GroupBox7.Controls.Add(this.ButtonSave4);
            this.GroupBox7.Controls.Add(this.TextBoxInvoiceDate);
            this.GroupBox7.Controls.Add(this.TextBoxOrderID4);
            this.GroupBox7.Controls.Add(this.TextBoxCID4);
            this.GroupBox7.Controls.Add(this.LabelInvoiceDate);
            this.GroupBox7.Controls.Add(this.LabelOrderID4);
            this.GroupBox7.Controls.Add(this.Label4Digits3);
            this.GroupBox7.Controls.Add(this.LabelCID4);
            this.GroupBox7.Controls.Add(this.TextBoxID4);
            this.GroupBox7.Controls.Add(this.LabelID4);
            this.GroupBox7.Location = new System.Drawing.Point(21, 26);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(429, 205);
            this.GroupBox7.TabIndex = 12;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Invoices Information";
            // 
            // ButtonExit
            // 
            this.ButtonExit.Location = new System.Drawing.Point(315, 176);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit.TabIndex = 26;
            this.ButtonExit.Text = "&Exit";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // ButtonReset3
            // 
            this.ButtonReset3.Location = new System.Drawing.Point(315, 138);
            this.ButtonReset3.Name = "ButtonReset3";
            this.ButtonReset3.Size = new System.Drawing.Size(75, 23);
            this.ButtonReset3.TabIndex = 25;
            this.ButtonReset3.Text = "&Reset";
            this.ButtonReset3.UseVisualStyleBackColor = true;
            this.ButtonReset3.Click += new System.EventHandler(this.ButtonReset3_Click);
            // 
            // ButtonPrintInvoice
            // 
            this.ButtonPrintInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonPrintInvoice.Location = new System.Drawing.Point(91, 176);
            this.ButtonPrintInvoice.Name = "ButtonPrintInvoice";
            this.ButtonPrintInvoice.Size = new System.Drawing.Size(128, 23);
            this.ButtonPrintInvoice.TabIndex = 5;
            this.ButtonPrintInvoice.Text = "Print Invoice";
            this.ButtonPrintInvoice.UseVisualStyleBackColor = true;
            this.ButtonPrintInvoice.Click += new System.EventHandler(this.ButtonPrintInvoice_Click);
            // 
            // ButtonDelete4
            // 
            this.ButtonDelete4.Location = new System.Drawing.Point(315, 101);
            this.ButtonDelete4.Name = "ButtonDelete4";
            this.ButtonDelete4.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete4.TabIndex = 13;
            this.ButtonDelete4.Text = "&Delete";
            this.ButtonDelete4.UseVisualStyleBackColor = true;
            this.ButtonDelete4.Click += new System.EventHandler(this.ButtonDelete4_Click);
            // 
            // ButtonUpdate4
            // 
            this.ButtonUpdate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate4.Location = new System.Drawing.Point(315, 62);
            this.ButtonUpdate4.Name = "ButtonUpdate4";
            this.ButtonUpdate4.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate4.TabIndex = 12;
            this.ButtonUpdate4.Text = "&Update";
            this.ButtonUpdate4.UseVisualStyleBackColor = true;
            this.ButtonUpdate4.Click += new System.EventHandler(this.ButtonUpdate4_Click);
            // 
            // ButtonSave4
            // 
            this.ButtonSave4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave4.Location = new System.Drawing.Point(315, 24);
            this.ButtonSave4.Name = "ButtonSave4";
            this.ButtonSave4.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave4.TabIndex = 11;
            this.ButtonSave4.Text = "&Save";
            this.ButtonSave4.UseVisualStyleBackColor = true;
            this.ButtonSave4.Click += new System.EventHandler(this.ButtonSave4_Click);
            // 
            // TextBoxInvoiceDate
            // 
            this.TextBoxInvoiceDate.Location = new System.Drawing.Point(163, 128);
            this.TextBoxInvoiceDate.Name = "TextBoxInvoiceDate";
            this.TextBoxInvoiceDate.Size = new System.Drawing.Size(100, 20);
            this.TextBoxInvoiceDate.TabIndex = 10;
            // 
            // TextBoxOrderID4
            // 
            this.TextBoxOrderID4.Location = new System.Drawing.Point(24, 128);
            this.TextBoxOrderID4.Name = "TextBoxOrderID4";
            this.TextBoxOrderID4.Size = new System.Drawing.Size(100, 20);
            this.TextBoxOrderID4.TabIndex = 9;
            // 
            // TextBoxCID4
            // 
            this.TextBoxCID4.Location = new System.Drawing.Point(161, 62);
            this.TextBoxCID4.Name = "TextBoxCID4";
            this.TextBoxCID4.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCID4.TabIndex = 7;
            // 
            // LabelInvoiceDate
            // 
            this.LabelInvoiceDate.AutoSize = true;
            this.LabelInvoiceDate.Location = new System.Drawing.Point(183, 111);
            this.LabelInvoiceDate.Name = "LabelInvoiceDate";
            this.LabelInvoiceDate.Size = new System.Drawing.Size(68, 13);
            this.LabelInvoiceDate.TabIndex = 6;
            this.LabelInvoiceDate.Text = "Invoice Date";
            // 
            // LabelOrderID4
            // 
            this.LabelOrderID4.AutoSize = true;
            this.LabelOrderID4.Location = new System.Drawing.Point(50, 111);
            this.LabelOrderID4.Name = "LabelOrderID4";
            this.LabelOrderID4.Size = new System.Drawing.Size(47, 13);
            this.LabelOrderID4.TabIndex = 5;
            this.LabelOrderID4.Text = "Order ID";
            // 
            // Label4Digits3
            // 
            this.Label4Digits3.AutoSize = true;
            this.Label4Digits3.Location = new System.Drawing.Point(39, 89);
            this.Label4Digits3.Name = "Label4Digits3";
            this.Label4Digits3.Size = new System.Drawing.Size(51, 13);
            this.Label4Digits3.TabIndex = 4;
            this.Label4Digits3.Text = "( 4 Digits)";
            // 
            // LabelCID4
            // 
            this.LabelCID4.AutoSize = true;
            this.LabelCID4.Location = new System.Drawing.Point(183, 41);
            this.LabelCID4.Name = "LabelCID4";
            this.LabelCID4.Size = new System.Drawing.Size(65, 13);
            this.LabelCID4.TabIndex = 2;
            this.LabelCID4.Text = "Customer ID";
            // 
            // TextBoxID4
            // 
            this.TextBoxID4.Location = new System.Drawing.Point(24, 62);
            this.TextBoxID4.Name = "TextBoxID4";
            this.TextBoxID4.Size = new System.Drawing.Size(100, 20);
            this.TextBoxID4.TabIndex = 1;
            // 
            // LabelID4
            // 
            this.LabelID4.AutoSize = true;
            this.LabelID4.Location = new System.Drawing.Point(41, 41);
            this.LabelID4.Name = "LabelID4";
            this.LabelID4.Size = new System.Drawing.Size(56, 13);
            this.LabelID4.TabIndex = 0;
            this.LabelID4.Text = "Invoice ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(176, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "YYYY-MM-DD";
            // 
            // Form5Accountant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(733, 450);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.GroupBox8);
            this.Controls.Add(this.GroupBox7);
            this.Name = "Form5Accountant";
            this.Text = "FormAccountant";
            this.Load += new System.EventHandler(this.FormAccountant_Load);
            this.GroupBox8.ResumeLayout(false);
            this.GroupBox8.PerformLayout();
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Order_ID;
        private System.Windows.Forms.ColumnHeader Customer_ID;
        private System.Windows.Forms.ComboBox ComboBox4;
        private System.Windows.Forms.TextBox TextBoxSearch4;
        private System.Windows.Forms.Label LabelEnter4;
        private System.Windows.Forms.Button ButtonSearch4;
        private System.Windows.Forms.GroupBox GroupBox8;
        private System.Windows.Forms.Label LabelSearchBy4;
        private System.Windows.Forms.GroupBox GroupBox7;
        private System.Windows.Forms.Button ButtonList4;
        private System.Windows.Forms.Button ButtonDelete4;
        private System.Windows.Forms.Button ButtonUpdate4;
        private System.Windows.Forms.Button ButtonSave4;
        private System.Windows.Forms.TextBox TextBoxInvoiceDate;
        private System.Windows.Forms.TextBox TextBoxOrderID4;
        private System.Windows.Forms.TextBox TextBoxCID4;
        private System.Windows.Forms.Label LabelInvoiceDate;
        private System.Windows.Forms.Label LabelOrderID4;
        private System.Windows.Forms.Label Label4Digits3;
        private System.Windows.Forms.Label LabelCID4;
        private System.Windows.Forms.TextBox TextBoxID4;
        private System.Windows.Forms.Label LabelID4;
        private System.Windows.Forms.ColumnHeader Invoice_ID;
        private System.Windows.Forms.ColumnHeader Invoice_Date;
        private System.Windows.Forms.Button ButtonPrintInvoice;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Button ButtonReset3;
        private System.Windows.Forms.Button ButtonCP4;
        private System.Windows.Forms.Label label1;
    }
}