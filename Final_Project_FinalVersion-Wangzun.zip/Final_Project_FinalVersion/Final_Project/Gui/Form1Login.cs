﻿using Final_Project.DataAccess;
using Final_Project.Business;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form1Login : Form
    {
        public Form1Login()
        {
            InitializeComponent();
        }

        //initialization
        public static SqlConnection connDB = UtilityDB.ConnDB();
        public static SqlCommand cmd = new SqlCommand();


        //button login
        private void ButtonLogin_Click(object sender, EventArgs e)
        {

            //reading login saving data from database
            if (TextBoxLoginID.Text == "" || TextBoxPassword.Text == "")
            {
                MessageBox.Show("input can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    Login login = new Login
                    {
                        Login_Id = Convert.ToInt32(TextBoxLoginID.Text),
                        Password = TextBoxPassword.Text
                    };

                    var dt = login.SearchUsers(login);
                    var numberOfFound = dt.Rows.Count;

                    if (numberOfFound > 0)
                    {
                        MessageBox.Show("logged in successfully! Welcome for use our application!");
                        Form2Manager manager = new Form2Manager();
                        Form3SalesManager sales = new Form3SalesManager();
                        Form4OrderClerks clerks = new Form4OrderClerks();
                        Form5Accountant account = new Form5Accountant();
                        Form6Inventory inven = new Form6Inventory();

                        switch (login.Login_Id)
                        {
                            case 1111:
                                this.Hide();
                                manager.ShowDialog();
                                this.Close();
                                break;
                            case 2222:
                                this.Hide();
                                sales.ShowDialog();
                                this.Close();
                                break;
                            case 3333:
                                this.Hide();
                                clerks.ShowDialog();
                                this.Close();
                                break;
                            case 4444:
                                this.Hide();
                                account.ShowDialog();
                                this.Close();
                                break;
                            case 5555:
                                this.Hide();
                                inven.ShowDialog();
                                this.Close();
                                break;
                        }
                    }
                    else{
                        MessageBox.Show("Login Error... Try again ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.TextBoxLoginID.Clear();
                        this.TextBoxPassword.Clear();
                        this.TextBoxLoginID.Focus();
                    }
                }
                catch
                {
                    MessageBox.Show("Input datatype not right, Login Error... Try again ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.TextBoxLoginID.Clear();
                    this.TextBoxPassword.Clear();
                    this.TextBoxLoginID.Focus();
                }
            }
        }
    }
}
