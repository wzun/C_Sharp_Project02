﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form6Inventory : Form
    {
        //--------for book tab--------
        public enum SearchBy
        {
            undefined, ISBN, Title, Category_type, Publisher_name, Author_Id           
        }
        //--------for author tab--------
        public enum SearchBy_A
        {
            undefined, Author_Id, First_Name, Last_Name, Email
        }

        public Form6Inventory()
        {
            InitializeComponent();
        }

        //---------connect to DB-------
        FinalProjectDBEntities context = new FinalProjectDBEntities();

        //----------Form load---------------
        private void FormInventory_Load(object sender, EventArgs e)
        {           
                foreach (SearchBy type in Enum.GetValues(typeof(SearchBy)))
                {
                    this.ComboBox6.Items.Add(type);
                }
                this.ComboBox6.Text = Convert.ToString(ComboBox6.Items[0]);

                ListView1.FullRowSelect = true;

                PopulateView();                     
        }

        // ----------function list data in the listview-----------
        private void PopulateView()
        {
            var booklist = from book in context.Books
                            select book;
            ListView1.Items.Clear();
            foreach (var book in booklist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(book.ISBN));
                item.SubItems.Add(book.Title);
                item.SubItems.Add(Convert.ToString(book.UnitPrice));
                item.SubItems.Add(Convert.ToString(book.YEARPublished));
                item.SubItems.Add(Convert.ToString(book.QOH));
                item.SubItems.Add(book.Category_type);
                item.SubItems.Add(book.Publisher_name);
                item.SubItems.Add(Convert.ToString(book.Author_Id));

                ListView1.Items.Add(item); 
            }
        }

        // ----------function1 list data in the listview-----------
        private void PopulateView1(Book book)
        {
            ListView1.Items.Clear();

            ListViewItem item = new ListViewItem(Convert.ToString(book.ISBN));
            item.SubItems.Add(book.Title);
            item.SubItems.Add(Convert.ToString(book.UnitPrice));
            item.SubItems.Add(Convert.ToString(book.YEARPublished));
            item.SubItems.Add(Convert.ToString(book.QOH));
            item.SubItems.Add(book.Category_type);
            item.SubItems.Add(book.Publisher_name);
            item.SubItems.Add(Convert.ToString(book.Author_Id));

            ListView1.Items.Add(item);
        }

        // ----------function search by string and list data in the listview-----------
        private void PopulateView2(List<Book> booklist)
        {
            ListView1.Items.Clear();
            foreach (var book in booklist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(book.ISBN));
                item.SubItems.Add(book.Title);
                item.SubItems.Add(Convert.ToString(book.UnitPrice));
                item.SubItems.Add(Convert.ToString(book.YEARPublished));
                item.SubItems.Add(Convert.ToString(book.QOH));
                item.SubItems.Add(book.Category_type);
                item.SubItems.Add(book.Publisher_name);
                item.SubItems.Add(Convert.ToString(book.Author_Id));

                ListView1.Items.Add(item);
            }
        }

        //------select listview and put data into the textbox-------
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = ListView1.SelectedItems[0];
            TextBoxISBN.Text = item.SubItems[0].Text;
            TextBoxTitle.Text = item.SubItems[1].Text;
            TextBoxUnitPrice.Text = item.SubItems[2].Text;
            TextBoxYP.Text = item.SubItems[3].Text;
            TextBoxQOH.Text = item.SubItems[4].Text;
            TextBoxCT.Text = item.SubItems[5].Text;
            TextBoxPName.Text = item.SubItems[6].Text;
            TextBoxAuthorId.Text = item.SubItems[7].Text;

            TextBoxISBN.Enabled = false;
        }

        //--------------function empty all the input---------------
        public void Empty_Input()
        {
            TextBoxISBN.Text = "";
            TextBoxTitle.Text = "";
            TextBoxUnitPrice.Text = "";
            TextBoxYP.Text = "";
            TextBoxQOH.Text = "";
            TextBoxCT.Text = "";
            TextBoxPName.Text = "";
            TextBoxAuthorId.Text = "";
        }



        //----------list------------
        private void ButtonListAll6_Click(object sender, EventArgs e)
        {
            PopulateView();
        }

        //----------save------------
        private void ButtonSave6_Click(object sender, EventArgs e)
        {
            Book book = new Book();

            int searchISBN = Convert.ToInt32(TextBoxISBN.Text.Trim());
            Book book1 = context.Books.Find(searchISBN);
            if (book1 != null)
            {
                MessageBox.Show("Dupicated Book ISBN", "Error");
                TextBoxISBN.Clear();
                TextBoxISBN.Focus();
                return;
            }
            else
            {
                book.ISBN = Convert.ToInt32(TextBoxISBN.Text.Trim());
            }

            book.Title = TextBoxTitle.Text.Trim();
            book.UnitPrice = Convert.ToInt32(TextBoxUnitPrice.Text.Trim());
            book.YEARPublished = Convert.ToDateTime(TextBoxYP.Text.Trim());
            book.QOH = Convert.ToInt32(TextBoxQOH.Text.Trim());
            book.Category_type = TextBoxCT.Text.Trim();
            book.Publisher_name = TextBoxPName.Text.Trim();
            book.Author_Id = Convert.ToInt32(TextBoxAuthorId.Text.Trim());

            context.Books.Add(book);
            context.SaveChanges();

            PopulateView();
            MessageBox.Show("Book saved successfully!");
            Empty_Input();
        }
        
        //----------update------------
        private void ButtonUpdate6_Click(object sender, EventArgs e)
        {
            if (TextBoxISBN.Text == "" || TextBoxTitle.Text == "" || TextBoxUnitPrice.Text == ""
                || TextBoxYP.Text == "" || TextBoxQOH.Text == ""
                || TextBoxCT.Text == "" || TextBoxPName.Text == ""
                || TextBoxAuthorId.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int bookISBN = Convert.ToInt32(TextBoxISBN.Text.Trim());
                Book book = context.Books.Find(bookISBN);
                if (book != null)
                {
                    TextBoxISBN.Enabled = false;

                    book.ISBN = Convert.ToInt32(TextBoxISBN.Text.Trim());
                    book.Title = TextBoxTitle.Text.Trim();
                    book.UnitPrice = Convert.ToInt32(TextBoxUnitPrice.Text.Trim());
                    book.YEARPublished = Convert.ToDateTime(TextBoxYP.Text.Trim());
                    book.QOH = Convert.ToInt32(TextBoxQOH.Text.Trim());
                    book.Category_type = TextBoxCT.Text.Trim();
                    book.Publisher_name = TextBoxPName.Text.Trim();
                    book.Author_Id = Convert.ToInt32(TextBoxAuthorId.Text.Trim());

                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Book update successfully!");
                }
                else
                {
                    TextBoxISBN.Enabled = true;
                    MessageBox.Show("Book not Found!");
                }
            }
            Empty_Input();
        }
        
        //----------delete------------
        private void ButtonDelete6_Click(object sender, EventArgs e)
        {
            if (TextBoxISBN.Text == "" || TextBoxTitle.Text == "" || TextBoxUnitPrice.Text == ""
                || TextBoxYP.Text == "" || TextBoxQOH.Text == ""
                || TextBoxCT.Text == "" || TextBoxPName.Text == ""
                || TextBoxAuthorId.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int bookISBN = Convert.ToInt32(TextBoxISBN.Text.Trim());
                Book book = context.Books.Find(bookISBN);
                if (book != null)
                {
                    TextBoxISBN.Enabled = false;

                    context.Books.Remove(book);
                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Book delete successfully!");
                }
                else
                {
                    TextBoxISBN.Enabled = true;
                    MessageBox.Show("Book not Found!");
                }
                Empty_Input();
            }
        }

        //----------search------------
        private void ButtonSearch6_Click(object sender, EventArgs e)
        {
            if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[1]))
                {
                    int bookISBN = Convert.ToInt32(TextBoxSearch6.Text.Trim());
                    Book book = context.Books.Find(bookISBN);
                    if (book != null)
                    {
                        PopulateView1(book);
                    }
                    else
                    {
                        MessageBox.Show("Book not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch6.Text = "";
                        TextBoxSearch6.Focus();
                    }
                }
                else if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[2]))
                {
                    string bookTi = TextBoxSearch6.Text.Trim();
                    var listBook = context.Books.Where(Ti => Ti.Title == bookTi).ToList<Book>();

                    if (listBook.Count != 0)
                    {
                        PopulateView2(listBook);
                    }
                    else
                    {
                        MessageBox.Show("Book not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch6.Text = "";
                        TextBoxSearch6.Focus();
                    }
                }
                else if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[3]))
                {
                    string bookCT = TextBoxSearch6.Text.Trim();

                    var listBook = context.Books.Where(CT => CT.Category_type == bookCT).ToList<Book>();

                    if (listBook.Count != 0)
                    {
                        PopulateView2(listBook);
                    }
                    else
                    {
                        MessageBox.Show("Book not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch6.Text = "";
                        TextBoxSearch6.Focus();
                    }
                }
                else if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[4]))
                {
                    string bookPN = TextBoxSearch6.Text.Trim();
                    var listBook = context.Books.Where(PN => PN.Publisher_name == bookPN).ToList<Book>();

                    if (listBook.Count != 0)
                    {
                        PopulateView2(listBook);
                    }
                    else
                    {
                        MessageBox.Show("Book not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch6.Text = "";
                        TextBoxSearch6.Focus();
                    }
                }
                else if (ComboBox6.Text == Convert.ToString(ComboBox6.Items[5]))
                {
                    string bookAI = TextBoxSearch6.Text.Trim();
                    int i = Convert.ToInt32(bookAI);
                    var listBook = context.Books.Where(AI => AI.Author_Id == i).ToList<Book>();
                    if (listBook.Count != 0)
                    {
                        PopulateView2(listBook);
                    }
                    else
                    {
                        MessageBox.Show("Book not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch6.Text = "";
                        TextBoxSearch6.Focus();
                    }
                }
            }
        }
        
        //----------reset------------
        private void ButtonReset6_Click(object sender, EventArgs e)
        {
            TextBoxISBN.Text = "";
            TextBoxTitle.Text = "";
            TextBoxUnitPrice.Text = "";
            TextBoxYP.Text = "";
            TextBoxQOH.Text = "";
            TextBoxCT.Text = "";
            TextBoxPName.Text = "";
            TextBoxAuthorId.Text = "";
            TextBoxISBN.Focus();
        }
        
        //----------exit------------
        private void ButtonExit6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome for use, see you next time !");
            this.Close();
        }



        //-------------------change tabControl------------------------
        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (this.TabControl1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("TabPage Inventory_Control is Selected !");
                    break;
                case 1:
                    MessageBox.Show("TabPage Author_Infomation is Selected !");
                    
                        foreach (SearchBy_A type in Enum.GetValues(typeof(SearchBy_A)))
                        {
                            this.ComboBox7.Items.Add(type);
                        }
                        this.ComboBox7.Text = Convert.ToString(ComboBox7.Items[0]);

                        ListView2.FullRowSelect = true;

                        PopulateView_A();
                   
                    break;
            }

            this.ChangeTabPage();
        }

        //----------------function change tabPage----------------------
        private void ChangeTabPage()
        {
            if (this.MdiChildren.Length > 0 && TabControl1.SelectedIndex > -1)
            {
                for (int i = 0; i < this.MdiChildren.Length; i++)
                {
                    if (this.TabControl1.SelectedIndex == i)
                    {
                        this.MdiChildren[i].WindowState = FormWindowState.Maximized;
                        this.MdiChildren[i].Visible = true;
                        this.MdiChildren[i].Activate();

                    }
                    else if (this.MdiChildren[i].Visible == true)
                    {
                        this.MdiChildren[i].Visible = false;
                    }
                }
            }
        }




        //--------------------------------------tab2--------------------------------------

        // ----------function list data in the listview-----------
        private void PopulateView_A()
        {
            var authorlist = from author in context.Authors
                           select author;
            ListView2.Items.Clear();
            foreach (var author in authorlist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(author.Author_Id));
                item.SubItems.Add(author.First_Name);
                item.SubItems.Add(author.Last_Name);
                item.SubItems.Add(author.Email);

                ListView2.Items.Add(item);
            }
        }

        // ----------function1 list data in the listview-----------
        private void PopulateView1_A(Author author)
        {
            ListView2.Items.Clear();

            ListViewItem item = new ListViewItem(Convert.ToString(author.Author_Id));
            item.SubItems.Add(author.First_Name);
            item.SubItems.Add(author.Last_Name);
            item.SubItems.Add(author.Email);

            ListView2.Items.Add(item);
        }

        // ----------function search by string and list data in the listview-----------
        private void PopulateView2_A(List<Author> authorlist)
        {
            ListView2.Items.Clear();
            foreach (var author in authorlist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(author.Author_Id));
                item.SubItems.Add(author.First_Name);
                item.SubItems.Add(author.Last_Name);
                item.SubItems.Add(author.Email);

                ListView2.Items.Add(item);
            }
        }

        //------select listview and put data into the textbox-------
        private void ListView2_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = ListView2.SelectedItems[0];
            TextBoxAId.Text = item.SubItems[0].Text;
            TextBoxFN7.Text = item.SubItems[1].Text;
            TextBoxPN.Text = item.SubItems[2].Text;
            TextBoxEmail.Text = item.SubItems[3].Text;

            TextBoxAId.Enabled = false;
        }

        //--------------function empty all the input---------------
        public void Empty_Input_A()
        {
            TextBoxAId.Text = "";
            TextBoxFN7.Text = "";
            TextBoxPN.Text = "";
            TextBoxEmail.Text = "";
        }



        //----------author list------------
        private void ButtonListAll7_Click(object sender, EventArgs e)
        {
            PopulateView_A();
        }

        //----------author save------------
        private void ButtonSave7_Click(object sender, EventArgs e)
        {
            Author author = new Author();
            int searchAuthor = Convert.ToInt32(TextBoxAId.Text.Trim());
            Author author1 = context.Authors.Find(searchAuthor);
            if (author1 != null)
            {
                MessageBox.Show("Dupicated author ID", "Error");
                TextBoxAId.Clear();
                TextBoxAId.Focus();
                return;
            }
            else
            {
                author.Author_Id = Convert.ToInt32(TextBoxAId.Text.Trim());
            }

            author.First_Name = TextBoxFN7.Text.Trim();
            author.Last_Name = TextBoxPN.Text.Trim();
            author.Email = TextBoxEmail.Text.Trim();

            context.Authors.Add(author);
            context.SaveChanges();

            PopulateView_A();
            MessageBox.Show("Author saved successfully!");
            Empty_Input_A();
        }   

        //----------author update------------
        private void ButtonUpdate7_Click(object sender, EventArgs e)
        {
            if (TextBoxAId.Text == "" || TextBoxFN7.Text == "" || TextBoxPN.Text == ""
                || TextBoxEmail.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int author_Id = Convert.ToInt32(TextBoxAId.Text.Trim());
                Author author = context.Authors.Find(author_Id);
                if (author != null)
                {
                    TextBoxAId.Enabled = false;

                    author.Author_Id = Convert.ToInt32(TextBoxAId.Text.Trim());
                    author.First_Name = TextBoxFN7.Text.Trim();
                    author.Last_Name = TextBoxPN.Text.Trim();
                    author.Email = TextBoxEmail.Text.Trim();

                    context.SaveChanges();
                    PopulateView_A();
                    MessageBox.Show("Author update successfully!");
                }
                else
                {
                    TextBoxAId.Enabled = true;
                    MessageBox.Show("Author not Found!");
                }
            }
            Empty_Input_A();
        }

        //----------author delete------------
        private void ButtonDelete7_Click(object sender, EventArgs e)
        {
            if (TextBoxAId.Text == "" || TextBoxFN7.Text == "" || TextBoxPN.Text == ""
                || TextBoxEmail.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int author_Id = Convert.ToInt32(TextBoxAId.Text.Trim());
                Author author = context.Authors.Find(author_Id);
                if (author != null)
                {
                    TextBoxAId.Enabled = false;

                    context.Authors.Remove(author);
                    context.SaveChanges();
                    PopulateView_A();
                    MessageBox.Show("Author delete successfully!");
                }
                else
                {
                    TextBoxAId.Enabled = true;
                    MessageBox.Show("Author not Found!");
                }
                Empty_Input_A();
            }
        }

        //----------author search------------
        private void ButtonSearch7_Click(object sender, EventArgs e)
        {
            if (ComboBox7.Text == Convert.ToString(ComboBox7.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ComboBox7.Text == Convert.ToString(ComboBox7.Items[1]))
                {
                    int author_Id = Convert.ToInt32(TextBoxSearch7.Text.Trim());
                    Author author = context.Authors.Find(author_Id);
                    if (author != null)
                    {
                        PopulateView1_A(author);
                    }
                    else
                    {
                        MessageBox.Show("Author not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch7.Text = "";
                        TextBoxSearch7.Focus();
                    }
                }
                else if (ComboBox7.Text == Convert.ToString(ComboBox7.Items[2]))
                {
                    string authorFN = TextBoxSearch7.Text.Trim();
                    var listAuthor = context.Authors.Where(FN => FN.First_Name == authorFN).ToList<Author>();

                    if (listAuthor.Count != 0)
                    {
                        PopulateView2_A(listAuthor);
                    }
                    else
                    {
                        MessageBox.Show("Author not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch7.Text = "";
                        TextBoxSearch7.Focus();
                    }
                }
                else if (ComboBox7.Text == Convert.ToString(ComboBox7.Items[3]))
                {
                    string authorLN = TextBoxSearch7.Text.Trim();
                    var listAuthor = context.Authors.Where(LN => LN.Last_Name == authorLN).ToList<Author>();

                    if (listAuthor.Count != 0)
                    {
                        PopulateView2_A(listAuthor);
                    }
                    else
                    {
                        MessageBox.Show("Author not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch7.Text = "";
                        TextBoxSearch7.Focus();
                    }
                }
                else if (ComboBox7.Text == Convert.ToString(ComboBox7.Items[4]))
                {
                    string authorE = TextBoxSearch7.Text.Trim();
                    var listAuthor = context.Authors.Where(E => E.Email == authorE).ToList<Author>();

                    if (listAuthor.Count != 0)
                    {
                        PopulateView2_A(listAuthor);
                    }
                    else
                    {
                        MessageBox.Show("Author not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch7.Text = "";
                        TextBoxSearch7.Focus();
                    }
                }
            }
        }

        //----------author exit------------
        private void ButtonExit7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome for use, see you next time !");
            this.Close();
        }

        private void ButtonCP5_Click(object sender, EventArgs e)
        {
            Form7ChangePassword form7 = new Form7ChangePassword();
            this.Hide();
            form7.ShowDialog();
            this.Close();
        }
    }
}
