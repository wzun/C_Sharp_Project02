﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form4OrderClerks : Form
    {
        public enum SearchBy
        {
            undefined, Order_Id, Customer_Id, ISBN, Payment, Take_type, Order_Date
        }

        public Form4OrderClerks()
        {
            InitializeComponent();
        }

        //---------connect to DB-------
        FinalProjectDBEntities context = new FinalProjectDBEntities();

        //----------Form load---------------
        private void FormOrderClerks_Load(object sender, EventArgs e)
        {
            foreach (SearchBy type in Enum.GetValues(typeof(SearchBy)))
            {
                this.ComboBox3.Items.Add(type);
            }
            this.ComboBox3.Text = Convert.ToString(ComboBox3.Items[0]);

            listView1.FullRowSelect = true;
            //TextBoxTotalPrice.Enabled = false;
            PopulateView();
        }

        // ----------function list data in the listview-----------
        private void PopulateView()
        {
            var orderlist = from order in context.Orders
                            select order;
            listView1.Items.Clear();
            foreach (var order in orderlist)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(order.Order_Id));
                item.SubItems.Add(Convert.ToString(order.Customer_Id));
                item.SubItems.Add(Convert.ToString(order.ISBN));
                item.SubItems.Add(Convert.ToString(order.Quantity));
                item.SubItems.Add(Convert.ToString(order.UnitPrice));
                item.SubItems.Add(Convert.ToString(order.TotalPrice));
                item.SubItems.Add(order.Payment);
                item.SubItems.Add(order.Take_type);
                item.SubItems.Add(Convert.ToString(order.Order_Date));

                listView1.Items.Add(item);
            }
        }

        // ----------function1 list data in the listview-----------
        private void PopulateView1(Order order)
        {
            listView1.Items.Clear();

            ListViewItem item = new ListViewItem(Convert.ToString(order.Order_Id));
            item.SubItems.Add(Convert.ToString(order.Customer_Id));
            item.SubItems.Add(Convert.ToString(order.ISBN));
            item.SubItems.Add(Convert.ToString(order.Quantity));
            item.SubItems.Add(Convert.ToString(order.UnitPrice));
            item.SubItems.Add(Convert.ToString(order.TotalPrice));
            item.SubItems.Add(order.Payment);
            item.SubItems.Add(order.Take_type);
            item.SubItems.Add(Convert.ToString(order.Order_Date));

            listView1.Items.Add(item);
        }

        // ----------function search by string and list data in the listview-----------
        private void PopulateView2(List<Order> listOrder)
        {
            listView1.Items.Clear();
            foreach (var order in listOrder)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(order.Order_Id));
                item.SubItems.Add(Convert.ToString(order.Customer_Id));
                item.SubItems.Add(Convert.ToString(order.ISBN));
                item.SubItems.Add(Convert.ToString(order.Quantity));
                item.SubItems.Add(Convert.ToString(order.UnitPrice));
                item.SubItems.Add(Convert.ToString(order.TotalPrice));
                item.SubItems.Add(order.Payment);
                item.SubItems.Add(order.Take_type);
                item.SubItems.Add(Convert.ToString(order.Order_Date));

                listView1.Items.Add(item);
            }
        }

        //------select listview and put data into the textbox-------
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = listView1.SelectedItems[0];
            TextBoxID3.Text = item.SubItems[0].Text;
            TextBoxCN3.Text = item.SubItems[1].Text;
            TextBoxISBN3.Text = item.SubItems[2].Text;
            TextBoxQuantity.Text = item.SubItems[3].Text;
            TextBoxUnitPrice.Text = item.SubItems[4].Text;
            TextBoxTotalPrice.Text = item.SubItems[5].Text;
            TextBoxPayment.Text = item.SubItems[6].Text;
            TextBoxTakeType.Text = item.SubItems[7].Text;
            TextBoxOrderDate.Text = item.SubItems[8].Text;

            TextBoxID3.Enabled = false;
        }

        //--------------function empty all the input---------------
        public void Empty_Input()
        {
            TextBoxID3.Text = "";
            TextBoxCN3.Text = "";
            TextBoxISBN3.Text = "";
            TextBoxQuantity.Text = "";
            TextBoxUnitPrice.Text = "";
            TextBoxTotalPrice.Text = "";
            TextBoxPayment.Text = "";
            TextBoxTakeType.Text = "";
            TextBoxOrderDate.Text = "";
        }

        //----------auto calculate total price------------
        private void TextBoxTotalPrice_Click(object sender, EventArgs e)
        {
            Decimal Tprice = Convert.ToInt32(TextBoxQuantity.Text.Trim()) * Convert.ToDecimal(TextBoxUnitPrice.Text.Trim());
            TextBoxTotalPrice.Text = Convert.ToString(Tprice);
        }



        //----------list------------
        private void ButtonList3_Click(object sender, EventArgs e)
        {
            PopulateView();
        }

        //----------save-------------
        private void ButtonSave3_Click(object sender, EventArgs e)
        {
            Order order = new Order();

            int searchOrder_Id = Convert.ToInt32(TextBoxID3.Text.Trim());
            Order order1 = context.Orders.Find(searchOrder_Id);
            if (order1 != null)
            {
                MessageBox.Show("Dupicated Order Id", "Error");
                TextBoxID3.Clear();
                TextBoxCN3.Focus();
                return;
            }
            else
            {
                order.Order_Id = Convert.ToInt32(TextBoxID3.Text.Trim());
            }

            order.Customer_Id = Convert.ToInt32(TextBoxCN3.Text.Trim());
            order.ISBN = Convert.ToInt32(TextBoxISBN3.Text.Trim());
            order.Quantity = Convert.ToInt32(TextBoxQuantity.Text.Trim());
            order.UnitPrice = Convert.ToDecimal(TextBoxUnitPrice.Text.Trim());
            order.TotalPrice = Convert.ToInt32(TextBoxQuantity.Text.Trim()) * Convert.ToDecimal(TextBoxUnitPrice.Text.Trim());
            order.Payment = TextBoxPayment.Text.Trim();
            order.Take_type = TextBoxTakeType.Text.Trim();
            order.Order_Date = Convert.ToDateTime(TextBoxOrderDate.Text.Trim());

            context.Orders.Add(order);
            context.SaveChanges();

            PopulateView();
            MessageBox.Show("Order saved successfully!");
            Empty_Input();
        }

        //----------update-----------
        private void ButtonUpdate3_Click(object sender, EventArgs e)
        {
            if (TextBoxID3.Text == "" || TextBoxCN3.Text == "" || TextBoxISBN3.Text == "" 
                || TextBoxQuantity.Text == "" || TextBoxUnitPrice.Text == "" 
                || TextBoxTotalPrice.Text == "" || TextBoxPayment.Text == "" 
                || TextBoxTakeType.Text == "" || TextBoxOrderDate.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int orderId = Convert.ToInt32(TextBoxID3.Text.Trim());
                Order order1 = context.Orders.Find(orderId);
                if (order1 != null)
                {
                    TextBoxID3.Enabled = false;

                    order1.Order_Id = Convert.ToInt32(TextBoxID3.Text.Trim());
                    order1.Customer_Id = Convert.ToInt32(TextBoxCN3.Text.Trim());
                    order1.ISBN = Convert.ToInt32(TextBoxISBN3.Text.Trim());
                    order1.Quantity = Convert.ToInt32(TextBoxQuantity.Text.Trim());
                    order1.UnitPrice = Convert.ToDecimal(TextBoxUnitPrice.Text.Trim());
                    order1.TotalPrice = Convert.ToInt32(TextBoxQuantity.Text.Trim()) * Convert.ToDecimal(TextBoxUnitPrice.Text.Trim());
                    order1.Payment = TextBoxPayment.Text.Trim();
                    order1.Take_type = TextBoxTakeType.Text.Trim();
                    order1.Order_Date = Convert.ToDateTime(TextBoxOrderDate.Text.Trim());

                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Order update successfully!");
                }
                else
                {
                    TextBoxID3.Enabled = true;
                    MessageBox.Show("Order not Found!");
                }
            }
            Empty_Input();
        }

        //----------delete-----------
        private void ButtonDelete3_Click(object sender, EventArgs e)
        {
            if (TextBoxID3.Text == "" || TextBoxCN3.Text == "" || TextBoxISBN3.Text == ""
                || TextBoxQuantity.Text == "" || TextBoxUnitPrice.Text == ""
                || TextBoxTotalPrice.Text == "" || TextBoxPayment.Text == ""
                || TextBoxTakeType.Text == "" || TextBoxOrderDate.Text == "")
            {
                MessageBox.Show("input data can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int orderId = Convert.ToInt32(TextBoxID3.Text.Trim());
                Order order1 = context.Orders.Find(orderId);

                if (order1 != null)
                {
                    TextBoxID3.Enabled = false;

                    context.Orders.Remove(order1);
                    context.SaveChanges();
                    PopulateView();
                    MessageBox.Show("Order delete successfully!");
                }
                else
                {
                    TextBoxID3.Enabled = true;
                    MessageBox.Show("Order not Found!");
                }
                Empty_Input();
            }
        }

        //----------search-----------
        private void ButtonSearch3_Click(object sender, EventArgs e)
        {
            if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[1]))
                {
                    int orderId = Convert.ToInt32(TextBoxSearch3.Text.Trim());
                    Order order1 = context.Orders.Find(orderId);
                    if (order1 != null)
                    {
                        PopulateView1(order1);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }

                }
                else if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[2]))
                {
                    string orderCI = TextBoxSearch3.Text.Trim();
                    int i = Convert.ToInt32(orderCI);
                    var listOrder = context.Orders.Where(CI => CI.Customer_Id == i).ToList<Order>();

                    if (listOrder.Count != 0)
                    {
                        PopulateView2(listOrder);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }
                }
                else if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[3]))
                {
                    string orderIS = TextBoxSearch3.Text.Trim();
                    int i = Convert.ToInt32(orderIS);
                    var listOrder = context.Orders.Where(IS => IS.ISBN == i).ToList<Order>();

                    if (listOrder.Count != 0)
                    {
                        PopulateView2(listOrder);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }
                }
                else if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[4]))
                {
                    string orderPa = TextBoxSearch3.Text.Trim();
                    var listOrder = context.Orders.Where(Pa => Pa.Payment == orderPa).ToList<Order>();

                    if (listOrder.Count != 0)
                    {
                        PopulateView2(listOrder);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }
                }
                else if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[5]))
                {
                    string orderTT = TextBoxSearch3.Text.Trim();
                    var listOrder = context.Orders.Where(TT => TT.Take_type == orderTT).ToList<Order>();

                    if (listOrder.Count != 0)
                    {
                        PopulateView2(listOrder);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }
                }
                else if (ComboBox3.Text == Convert.ToString(ComboBox3.Items[6]))
                {
                    string orderOD = TextBoxSearch3.Text.Trim();
                    DateTime i = Convert.ToDateTime(orderOD);
                    var listOrder = context.Orders.Where(OD => OD.Order_Date == i).ToList<Order>();

                    if (listOrder.Count != 0)
                    {
                        PopulateView2(listOrder);
                    }
                    else
                    {
                        MessageBox.Show("Order not Found!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxSearch3.Text = "";
                        TextBoxSearch3.Focus();
                    }
                }
            }
        }

        //----------reset-----------
        private void ButtonReset3_Click(object sender, EventArgs e)
        {
            TextBoxID3.Text = "";
            TextBoxCN3.Text = "";
            TextBoxISBN3.Text = "";
            TextBoxQuantity.Text = "";
            TextBoxUnitPrice.Text = "";
            TextBoxTotalPrice.Text = "";
            TextBoxPayment.Text = "";
            TextBoxTakeType.Text = "";
            TextBoxOrderDate.Text = "";
            TextBoxID3.Focus();
        }

        //----------exit-----------
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome for use, see you next time !");
            this.Close();
        }

        private void ButtonCP3_Click(object sender, EventArgs e)
        {
            Form7ChangePassword form7 = new Form7ChangePassword();
            this.Hide();
            form7.ShowDialog();
            this.Close();
        }
    }
}
