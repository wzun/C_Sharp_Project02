﻿using Final_Project.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form2Manager : Form
    {
        //search categories
        public enum SearchBy
        {
            undefined, User_Id, FirstName, LastName, Department, Login_Id 
        }

        public Form2Manager()
        {
            InitializeComponent();
        }        

        //form load
        private void FormManager_Load(object sender, EventArgs e)
        {
            foreach (SearchBy type in Enum.GetValues(typeof(SearchBy)))
            {
                this.ComboBoxSearch1.Items.Add(type);
            }
            this.ComboBoxSearch1.Text = Convert.ToString(ComboBoxSearch1.Items[0]);

            ListView1.FullRowSelect = true;

            Users user = new Users();
            var data = user.ListUsers();

            PopulateListView(data);

            TextBoxUserId.Enabled = false;
        }

        //function for load data into listview
        private void PopulateListView(DataTable data)
        {
            foreach (DataRow row in data.Rows)
            {
                ListViewItem item = new ListViewItem(row[0].ToString());
                for (int i = 1; i < data.Columns.Count; i++)
                {
                    item.SubItems.Add(row[i].ToString());
                }
                ListView1.Items.Add(item);
            }
        }

        //select data from listwiew
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = ListView1.SelectedItems[0];
            TextBoxUserId.Text = item.SubItems[0].Text;
            TextBoxFirstName.Text = item.SubItems[1].Text;
            TextBoxLastName.Text = item.SubItems[2].Text;
            TextBoxDepartment.Text = item.SubItems[3].Text;
            TextBoxLoginId.Text = item.SubItems[4].Text;
            TextBoxPassword.Text = item.SubItems[5].Text;

            TextBoxUserId.Enabled = false;
        }

        //empty_Input
        public void Empty_Input()
        {
            TextBoxUserId.Text = "";
            TextBoxFirstName.Text = "";
            TextBoxLastName.Text = "";
            TextBoxDepartment.Text = "";
            TextBoxLoginId.Text = "";
            TextBoxPassword.Text = "";
            TextBoxFirstName.Focus();
        }



        //list data from DB
        private void ButtonList_Click(object sender, EventArgs e)
        {
            Users user = new Users();
            var data = user.ListUsers();

            if (ListView1.Items.Count > 0)
            {
                ListView1.Items.Clear();
                PopulateListView(data);
            }
            else
            {
                PopulateListView(data);
            }

            TextBoxFirstName.Focus();
        }

        //save data into DB
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            if (TextBoxFirstName.Text == "" || TextBoxLastName.Text == "" || TextBoxDepartment.Text == ""
                 || TextBoxLoginId.Text == "" || TextBoxPassword.Text == "")
            {
                MessageBox.Show("Data input can't be empty !", "error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Users user = new Users
                {
                    First_Name = TextBoxFirstName.Text,
                    Last_Name = TextBoxLastName.Text,
                    Department = TextBoxDepartment.Text,
                    Login_Id = Convert.ToInt32(TextBoxLoginId.Text),
                    Password = TextBoxPassword.Text,
                };
               
                if (user.SaveUsers(user))
                {
                    Users user1 = new Users();
                    var data = user1.ListUsers();

                    ListView1.Items.Clear();
                    PopulateListView(data);

                    Empty_Input();

                    MessageBox.Show("Data saved successfully!");
                }
                else
                {
                    MessageBox.Show(" not successfully!", "error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        //update data from DB
        private void ButtonUpdate_Click(object sender, EventArgs e)
        {
            if (TextBoxUserId.Text == "" || TextBoxFirstName.Text == "" || TextBoxLastName.Text == ""
                || TextBoxDepartment.Text == "" || TextBoxLoginId.Text == "" || TextBoxPassword.Text == "")
            {
                MessageBox.Show("Data input can't be empty !", "error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Users user = new Users
                {
                    User_Id = Convert.ToInt32(TextBoxUserId.Text),
                    First_Name = TextBoxFirstName.Text,
                    Last_Name = TextBoxLastName.Text,
                    Department = TextBoxDepartment.Text,
                    Login_Id = Convert.ToInt32(TextBoxLoginId.Text),
                    Password = TextBoxPassword.Text,
                };

                if (user.UpdateUsers(user))
                {
                    Users user1 = new Users();
                    var data = user1.ListUsers();

                    if (ListView1.Items.Count > 0)
                    {
                        ListView1.Items.Clear();
                        PopulateListView(data);
                    }
                    else
                    {
                        PopulateListView(data);
                    }
                    MessageBox.Show("Data update successfully!");
                }
            }
            Empty_Input();
        }

        //delete data from DB
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            Users user = new Users
            {
                User_Id = Convert.ToInt32(TextBoxUserId.Text),
                First_Name = TextBoxFirstName.Text,
                Last_Name = TextBoxLastName.Text,
                Department = TextBoxDepartment.Text,
                Login_Id = Convert.ToInt32(TextBoxLoginId.Text),
                Password = TextBoxPassword.Text,
            };           
            if (user.DeleteUsers(user))
            {
                Users user1 = new Users();
                var data = user.ListUsers();

                ListView1.Items.Clear();
                PopulateListView(data);
                
                MessageBox.Show("Data delete successfully!");
            }
            else
            {
                MessageBox.Show("no data to delete", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Empty_Input();
        }
       
        //search data from DB
        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (TextBoxSearch1.Text == "")
            {
                MessageBox.Show("search keyword can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Users user = new Users();

                if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[1]))
                {
                    user.User_Id = Convert.ToInt32(TextBoxSearch1.Text);
                }
                else if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[2]))
                {
                    user.First_Name = TextBoxSearch1.Text;
                }
                else if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[3]))
                {
                    user.Last_Name = TextBoxSearch1.Text;
                }
                else if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[4]))
                {
                    user.Department = TextBoxSearch1.Text;
                }
                else if (ComboBoxSearch1.Text == Convert.ToString(ComboBoxSearch1.Items[5]))
                {
                    user.Login_Id = Convert.ToInt32(TextBoxSearch1.Text);
                }

                var data = user.SearchUsers(user);
                
                if (data.Rows.Count == 0)
                {
                    MessageBox.Show(" Data Not found !", "Information",
                                                         MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    if (ListView1.Items.Count > 0)
                    {
                        ListView1.Items.Clear();
                        PopulateListView(data);
                    }
                    else
                    {
                        PopulateListView(data);
                    }
                }               
            }
        }

        //reset the display 
        private void ButtonReset_Click(object sender, EventArgs e)
        {
            TextBoxUserId.Text = "";
            TextBoxFirstName.Text = "";
            TextBoxLastName.Text = "";
            TextBoxDepartment.Text = "";
            TextBoxLoginId.Text = "";
            TextBoxPassword.Text = "";
            TextBoxFirstName.Focus();
        }

        //exit
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome for use ,See you next time !");
            this.Close();
        }


        //-------------------change tabControl------------------------
        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (this.TabControl1.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("TabPage User is Selected !");
                    break;
                case 1:
                    MessageBox.Show("TabPage Employee is Selected, not available now!");
                    break;
            }

            this.ChangeTabPage();
        }

        //----------------function change tabPage----------------------
        private void ChangeTabPage()
        {
            if (this.MdiChildren.Length > 0 && TabControl1.SelectedIndex > -1)
            {
                for (int i = 0; i < this.MdiChildren.Length; i++)
                {
                    if (this.TabControl1.SelectedIndex == i)
                    {
                        this.MdiChildren[i].WindowState = FormWindowState.Maximized;
                        this.MdiChildren[i].Visible = true;
                        this.MdiChildren[i].Activate();

                    }
                    else if (this.MdiChildren[i].Visible == true)
                    {
                        this.MdiChildren[i].Visible = false;
                    }
                }
            }
        }

        //-------------------change password------------------------
        private void ButtonCP1_Click(object sender, EventArgs e)
        {
            Form7ChangePassword form7 = new Form7ChangePassword();
            this.Hide();
            form7.ShowDialog();
            this.Close();

        }
    }
}
