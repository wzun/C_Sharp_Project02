﻿using Final_Project.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form7ChangePassword : Form
    {
        public Form7ChangePassword()
        {
            InitializeComponent();
        }

        private void ButtonChange_Click(object sender, EventArgs e)
        {
            if (TextBoxLoginID.Text == "" || TextBoxNewPass.Text == "" || TextBoxPasswordC.Text == "")
            {
                MessageBox.Show("input can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (TextBoxNewPass.Text != TextBoxPasswordC.Text)
            {
                MessageBox.Show("The two input password are not same ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Login login = new Login
                {
                    Login_Id = Convert.ToInt32(TextBoxLoginID.Text),
                    Password = TextBoxNewPass.Text
                };
                var dt = login.SearchUsersExist(login);
                var numberOfFound = dt.Rows.Count;

                if (numberOfFound > 0)
                {
                    var dt1 = login.ChangePass(login);
                    MessageBox.Show("The password changed successfully!");
                    Form1Login form1Login = new Form1Login();
                    this.Hide();
                    form1Login.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("The Login_Id are not right, try again... ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }               
        }
    }
}
