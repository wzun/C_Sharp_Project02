﻿namespace Final_Project.Gui
{
    partial class Form6Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.ButtonSearch7 = new System.Windows.Forms.Button();
            this.ComboBox7 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch7 = new System.Windows.Forms.TextBox();
            this.LabelSearch7 = new System.Windows.Forms.Label();
            this.LabelSearchBy7 = new System.Windows.Forms.Label();
            this.ButtonListAll7 = new System.Windows.Forms.Button();
            this.TextBoxCT = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.ButtonExit7 = new System.Windows.Forms.Button();
            this.TextBoxEmail = new System.Windows.Forms.TextBox();
            this.TextBoxPN = new System.Windows.Forms.TextBox();
            this.TextBoxFN7 = new System.Windows.Forms.TextBox();
            this.LabelEmail6 = new System.Windows.Forms.Label();
            this.LabelLN6 = new System.Windows.Forms.Label();
            this.Label3Digits = new System.Windows.Forms.Label();
            this.LabelFN6 = new System.Windows.Forms.Label();
            this.TextBoxAId = new System.Windows.Forms.TextBox();
            this.LabelAuthorId = new System.Windows.Forms.Label();
            this.ButtonDelete7 = new System.Windows.Forms.Button();
            this.ButtonUpdate7 = new System.Windows.Forms.Button();
            this.ButtonSave7 = new System.Windows.Forms.Button();
            this.ButtonExit6 = new System.Windows.Forms.Button();
            this.LabelCT = new System.Windows.Forms.Label();
            this.ButtonDelete6 = new System.Windows.Forms.Button();
            this.TextBoxQOH = new System.Windows.Forms.TextBox();
            this.ButtonUpdate6 = new System.Windows.Forms.Button();
            this.TextBoxYP = new System.Windows.Forms.TextBox();
            this.ButtonSave6 = new System.Windows.Forms.Button();
            this.TextBoxUnitPrice = new System.Windows.Forms.TextBox();
            this.TextBoxISBN = new System.Windows.Forms.TextBox();
            this.TextBoxTitle = new System.Windows.Forms.TextBox();
            this.LabelISBN = new System.Windows.Forms.Label();
            this.LabelQOH = new System.Windows.Forms.Label();
            this.LabelTitle = new System.Windows.Forms.Label();
            this.LabelYP = new System.Windows.Forms.Label();
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ListView1 = new System.Windows.Forms.ListView();
            this.ISBN = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Title = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UnitPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.YEARPublished = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.QQH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Category_type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Publisher_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Author_Id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.ButtonCP5 = new System.Windows.Forms.Button();
            this.ButtonListAll6 = new System.Windows.Forms.Button();
            this.ButtonSearch6 = new System.Windows.Forms.Button();
            this.ComboBox6 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch6 = new System.Windows.Forms.TextBox();
            this.LabelEnter = new System.Windows.Forms.Label();
            this.LabelSearchBy = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.ButtonReset6 = new System.Windows.Forms.Button();
            this.TextBoxAuthorId = new System.Windows.Forms.TextBox();
            this.TextBoxPName = new System.Windows.Forms.TextBox();
            this.LabelPName = new System.Windows.Forms.Label();
            this.LabelAuthor_Id = new System.Windows.Forms.Label();
            this.LabelUnitPrice = new System.Windows.Forms.Label();
            this.LabelDigits = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ListView2 = new System.Windows.Forms.ListView();
            this.AuthorId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.First_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Last_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.ButtonSearch7);
            this.groupBox10.Controls.Add(this.ComboBox7);
            this.groupBox10.Controls.Add(this.TextBoxSearch7);
            this.groupBox10.Controls.Add(this.LabelSearch7);
            this.groupBox10.Controls.Add(this.LabelSearchBy7);
            this.groupBox10.Controls.Add(this.ButtonListAll7);
            this.groupBox10.Location = new System.Drawing.Point(502, 24);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(291, 161);
            this.groupBox10.TabIndex = 10;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Search Author";
            // 
            // ButtonSearch7
            // 
            this.ButtonSearch7.Location = new System.Drawing.Point(186, 113);
            this.ButtonSearch7.Name = "ButtonSearch7";
            this.ButtonSearch7.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch7.TabIndex = 4;
            this.ButtonSearch7.Text = "Search";
            this.ButtonSearch7.UseVisualStyleBackColor = true;
            this.ButtonSearch7.Click += new System.EventHandler(this.ButtonSearch7_Click);
            // 
            // ComboBox7
            // 
            this.ComboBox7.FormattingEnabled = true;
            this.ComboBox7.Location = new System.Drawing.Point(28, 50);
            this.ComboBox7.Name = "ComboBox7";
            this.ComboBox7.Size = new System.Drawing.Size(121, 21);
            this.ComboBox7.TabIndex = 3;
            // 
            // TextBoxSearch7
            // 
            this.TextBoxSearch7.Location = new System.Drawing.Point(28, 115);
            this.TextBoxSearch7.Name = "TextBoxSearch7";
            this.TextBoxSearch7.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch7.TabIndex = 2;
            // 
            // LabelSearch7
            // 
            this.LabelSearch7.AutoSize = true;
            this.LabelSearch7.Location = new System.Drawing.Point(28, 86);
            this.LabelSearch7.Name = "LabelSearch7";
            this.LabelSearch7.Size = new System.Drawing.Size(166, 13);
            this.LabelSearch7.TabIndex = 1;
            this.LabelSearch7.Text = "Please Enter keyword for search :";
            // 
            // LabelSearchBy7
            // 
            this.LabelSearchBy7.AutoSize = true;
            this.LabelSearchBy7.Location = new System.Drawing.Point(54, 28);
            this.LabelSearchBy7.Name = "LabelSearchBy7";
            this.LabelSearchBy7.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy7.TabIndex = 0;
            this.LabelSearchBy7.Text = "Search By";
            // 
            // ButtonListAll7
            // 
            this.ButtonListAll7.Location = new System.Drawing.Point(186, 51);
            this.ButtonListAll7.Name = "ButtonListAll7";
            this.ButtonListAll7.Size = new System.Drawing.Size(75, 23);
            this.ButtonListAll7.TabIndex = 14;
            this.ButtonListAll7.Text = "&List All";
            this.ButtonListAll7.UseVisualStyleBackColor = true;
            this.ButtonListAll7.Click += new System.EventHandler(this.ButtonListAll7_Click);
            // 
            // TextBoxCT
            // 
            this.TextBoxCT.Location = new System.Drawing.Point(259, 113);
            this.TextBoxCT.Name = "TextBoxCT";
            this.TextBoxCT.Size = new System.Drawing.Size(104, 20);
            this.TextBoxCT.TabIndex = 29;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.ButtonExit7);
            this.groupBox9.Controls.Add(this.TextBoxEmail);
            this.groupBox9.Controls.Add(this.TextBoxPN);
            this.groupBox9.Controls.Add(this.TextBoxFN7);
            this.groupBox9.Controls.Add(this.LabelEmail6);
            this.groupBox9.Controls.Add(this.LabelLN6);
            this.groupBox9.Controls.Add(this.Label3Digits);
            this.groupBox9.Controls.Add(this.LabelFN6);
            this.groupBox9.Controls.Add(this.TextBoxAId);
            this.groupBox9.Controls.Add(this.LabelAuthorId);
            this.groupBox9.Controls.Add(this.ButtonDelete7);
            this.groupBox9.Controls.Add(this.ButtonUpdate7);
            this.groupBox9.Controls.Add(this.ButtonSave7);
            this.groupBox9.Location = new System.Drawing.Point(21, 24);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(455, 161);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Author Information";
            // 
            // ButtonExit7
            // 
            this.ButtonExit7.Location = new System.Drawing.Point(342, 132);
            this.ButtonExit7.Name = "ButtonExit7";
            this.ButtonExit7.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit7.TabIndex = 26;
            this.ButtonExit7.Text = "&Exit";
            this.ButtonExit7.UseVisualStyleBackColor = true;
            this.ButtonExit7.Click += new System.EventHandler(this.ButtonExit7_Click);
            // 
            // TextBoxEmail
            // 
            this.TextBoxEmail.Location = new System.Drawing.Point(170, 123);
            this.TextBoxEmail.Name = "TextBoxEmail";
            this.TextBoxEmail.Size = new System.Drawing.Size(108, 20);
            this.TextBoxEmail.TabIndex = 25;
            // 
            // TextBoxPN
            // 
            this.TextBoxPN.Location = new System.Drawing.Point(39, 124);
            this.TextBoxPN.Name = "TextBoxPN";
            this.TextBoxPN.Size = new System.Drawing.Size(100, 20);
            this.TextBoxPN.TabIndex = 24;
            // 
            // TextBoxFN7
            // 
            this.TextBoxFN7.Location = new System.Drawing.Point(170, 51);
            this.TextBoxFN7.Name = "TextBoxFN7";
            this.TextBoxFN7.Size = new System.Drawing.Size(109, 20);
            this.TextBoxFN7.TabIndex = 22;
            // 
            // LabelEmail6
            // 
            this.LabelEmail6.AutoSize = true;
            this.LabelEmail6.Location = new System.Drawing.Point(203, 107);
            this.LabelEmail6.Name = "LabelEmail6";
            this.LabelEmail6.Size = new System.Drawing.Size(32, 13);
            this.LabelEmail6.TabIndex = 21;
            this.LabelEmail6.Text = "Email";
            // 
            // LabelLN6
            // 
            this.LabelLN6.AutoSize = true;
            this.LabelLN6.Location = new System.Drawing.Point(54, 107);
            this.LabelLN6.Name = "LabelLN6";
            this.LabelLN6.Size = new System.Drawing.Size(61, 13);
            this.LabelLN6.TabIndex = 20;
            this.LabelLN6.Text = "Last_Name";
            // 
            // Label3Digits
            // 
            this.Label3Digits.AutoSize = true;
            this.Label3Digits.Location = new System.Drawing.Point(54, 74);
            this.Label3Digits.Name = "Label3Digits";
            this.Label3Digits.Size = new System.Drawing.Size(51, 13);
            this.Label3Digits.TabIndex = 19;
            this.Label3Digits.Text = "( 3 Digits)";
            // 
            // LabelFN6
            // 
            this.LabelFN6.AutoSize = true;
            this.LabelFN6.Location = new System.Drawing.Point(193, 26);
            this.LabelFN6.Name = "LabelFN6";
            this.LabelFN6.Size = new System.Drawing.Size(60, 13);
            this.LabelFN6.TabIndex = 17;
            this.LabelFN6.Text = "First_Name";
            // 
            // TextBoxAId
            // 
            this.TextBoxAId.Location = new System.Drawing.Point(39, 51);
            this.TextBoxAId.Name = "TextBoxAId";
            this.TextBoxAId.Size = new System.Drawing.Size(100, 20);
            this.TextBoxAId.TabIndex = 16;
            // 
            // LabelAuthorId
            // 
            this.LabelAuthorId.AutoSize = true;
            this.LabelAuthorId.Location = new System.Drawing.Point(54, 26);
            this.LabelAuthorId.Name = "LabelAuthorId";
            this.LabelAuthorId.Size = new System.Drawing.Size(53, 13);
            this.LabelAuthorId.TabIndex = 15;
            this.LabelAuthorId.Text = "Author_Id";
            // 
            // ButtonDelete7
            // 
            this.ButtonDelete7.Location = new System.Drawing.Point(342, 84);
            this.ButtonDelete7.Name = "ButtonDelete7";
            this.ButtonDelete7.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete7.TabIndex = 13;
            this.ButtonDelete7.Text = "&Delete";
            this.ButtonDelete7.UseVisualStyleBackColor = true;
            this.ButtonDelete7.Click += new System.EventHandler(this.ButtonDelete7_Click);
            // 
            // ButtonUpdate7
            // 
            this.ButtonUpdate7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate7.Location = new System.Drawing.Point(342, 51);
            this.ButtonUpdate7.Name = "ButtonUpdate7";
            this.ButtonUpdate7.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate7.TabIndex = 12;
            this.ButtonUpdate7.Text = "&Update";
            this.ButtonUpdate7.UseVisualStyleBackColor = true;
            this.ButtonUpdate7.Click += new System.EventHandler(this.ButtonUpdate7_Click);
            // 
            // ButtonSave7
            // 
            this.ButtonSave7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave7.Location = new System.Drawing.Point(342, 19);
            this.ButtonSave7.Name = "ButtonSave7";
            this.ButtonSave7.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave7.TabIndex = 11;
            this.ButtonSave7.Text = "&Save";
            this.ButtonSave7.UseVisualStyleBackColor = true;
            this.ButtonSave7.Click += new System.EventHandler(this.ButtonSave7_Click);
            // 
            // ButtonExit6
            // 
            this.ButtonExit6.Location = new System.Drawing.Point(386, 184);
            this.ButtonExit6.Name = "ButtonExit6";
            this.ButtonExit6.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit6.TabIndex = 14;
            this.ButtonExit6.Text = "&Exit";
            this.ButtonExit6.UseVisualStyleBackColor = true;
            this.ButtonExit6.Click += new System.EventHandler(this.ButtonExit6_Click);
            // 
            // LabelCT
            // 
            this.LabelCT.AutoSize = true;
            this.LabelCT.Location = new System.Drawing.Point(278, 94);
            this.LabelCT.Name = "LabelCT";
            this.LabelCT.Size = new System.Drawing.Size(75, 13);
            this.LabelCT.TabIndex = 28;
            this.LabelCT.Text = "Category_type";
            // 
            // ButtonDelete6
            // 
            this.ButtonDelete6.Location = new System.Drawing.Point(386, 91);
            this.ButtonDelete6.Name = "ButtonDelete6";
            this.ButtonDelete6.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete6.TabIndex = 13;
            this.ButtonDelete6.Text = "&Delete";
            this.ButtonDelete6.UseVisualStyleBackColor = true;
            this.ButtonDelete6.Click += new System.EventHandler(this.ButtonDelete6_Click);
            // 
            // TextBoxQOH
            // 
            this.TextBoxQOH.Location = new System.Drawing.Point(143, 113);
            this.TextBoxQOH.Name = "TextBoxQOH";
            this.TextBoxQOH.Size = new System.Drawing.Size(104, 20);
            this.TextBoxQOH.TabIndex = 27;
            // 
            // ButtonUpdate6
            // 
            this.ButtonUpdate6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate6.Location = new System.Drawing.Point(386, 60);
            this.ButtonUpdate6.Name = "ButtonUpdate6";
            this.ButtonUpdate6.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate6.TabIndex = 12;
            this.ButtonUpdate6.Text = "&Update";
            this.ButtonUpdate6.UseVisualStyleBackColor = true;
            this.ButtonUpdate6.Click += new System.EventHandler(this.ButtonUpdate6_Click);
            // 
            // TextBoxYP
            // 
            this.TextBoxYP.Location = new System.Drawing.Point(21, 113);
            this.TextBoxYP.Name = "TextBoxYP";
            this.TextBoxYP.Size = new System.Drawing.Size(100, 20);
            this.TextBoxYP.TabIndex = 26;
            // 
            // ButtonSave6
            // 
            this.ButtonSave6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave6.Location = new System.Drawing.Point(386, 28);
            this.ButtonSave6.Name = "ButtonSave6";
            this.ButtonSave6.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave6.TabIndex = 11;
            this.ButtonSave6.Text = "&Save";
            this.ButtonSave6.UseVisualStyleBackColor = true;
            this.ButtonSave6.Click += new System.EventHandler(this.ButtonSave6_Click);
            // 
            // TextBoxUnitPrice
            // 
            this.TextBoxUnitPrice.Location = new System.Drawing.Point(263, 46);
            this.TextBoxUnitPrice.Name = "TextBoxUnitPrice";
            this.TextBoxUnitPrice.Size = new System.Drawing.Size(100, 20);
            this.TextBoxUnitPrice.TabIndex = 25;
            // 
            // TextBoxISBN
            // 
            this.TextBoxISBN.Location = new System.Drawing.Point(21, 46);
            this.TextBoxISBN.Name = "TextBoxISBN";
            this.TextBoxISBN.Size = new System.Drawing.Size(100, 20);
            this.TextBoxISBN.TabIndex = 18;
            // 
            // TextBoxTitle
            // 
            this.TextBoxTitle.Location = new System.Drawing.Point(141, 46);
            this.TextBoxTitle.Name = "TextBoxTitle";
            this.TextBoxTitle.Size = new System.Drawing.Size(100, 20);
            this.TextBoxTitle.TabIndex = 24;
            // 
            // LabelISBN
            // 
            this.LabelISBN.AutoSize = true;
            this.LabelISBN.Location = new System.Drawing.Point(41, 24);
            this.LabelISBN.Name = "LabelISBN";
            this.LabelISBN.Size = new System.Drawing.Size(32, 13);
            this.LabelISBN.TabIndex = 17;
            this.LabelISBN.Text = "ISBN";
            // 
            // LabelQOH
            // 
            this.LabelQOH.AutoSize = true;
            this.LabelQOH.Location = new System.Drawing.Point(138, 94);
            this.LabelQOH.Name = "LabelQOH";
            this.LabelQOH.Size = new System.Drawing.Size(122, 13);
            this.LabelQOH.TabIndex = 23;
            this.LabelQOH.Text = "QOH(Quantity On Hand)";
            // 
            // LabelTitle
            // 
            this.LabelTitle.AutoSize = true;
            this.LabelTitle.Location = new System.Drawing.Point(166, 25);
            this.LabelTitle.Name = "LabelTitle";
            this.LabelTitle.Size = new System.Drawing.Size(27, 13);
            this.LabelTitle.TabIndex = 19;
            this.LabelTitle.Text = "Title";
            // 
            // LabelYP
            // 
            this.LabelYP.AutoSize = true;
            this.LabelYP.Location = new System.Drawing.Point(27, 94);
            this.LabelYP.Name = "LabelYP";
            this.LabelYP.Size = new System.Drawing.Size(82, 13);
            this.LabelYP.TabIndex = 22;
            this.LabelYP.Text = "YEARPublished";
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.tabPage1);
            this.TabControl1.Controls.Add(this.tabPage2);
            this.TabControl1.Location = new System.Drawing.Point(26, 12);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(822, 413);
            this.TabControl1.TabIndex = 1;
            this.TabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.ListView1);
            this.tabPage1.Controls.Add(this.GroupBox2);
            this.tabPage1.Controls.Add(this.GroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(814, 387);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Inventory_Control";
            // 
            // ListView1
            // 
            this.ListView1.BackColor = System.Drawing.Color.Silver;
            this.ListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ISBN,
            this.Title,
            this.UnitPrice,
            this.YEARPublished,
            this.QQH,
            this.Category_type,
            this.Publisher_name,
            this.Author_Id});
            this.ListView1.GridLines = true;
            this.ListView1.Location = new System.Drawing.Point(16, 238);
            this.ListView1.Name = "ListView1";
            this.ListView1.Size = new System.Drawing.Size(772, 146);
            this.ListView1.TabIndex = 8;
            this.ListView1.UseCompatibleStateImageBehavior = false;
            this.ListView1.View = System.Windows.Forms.View.Details;
            this.ListView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView1_MouseClick);
            // 
            // ISBN
            // 
            this.ISBN.Text = "ISBN";
            this.ISBN.Width = 66;
            // 
            // Title
            // 
            this.Title.Text = "Title";
            this.Title.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Title.Width = 92;
            // 
            // UnitPrice
            // 
            this.UnitPrice.Text = "UnitPrice";
            this.UnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UnitPrice.Width = 96;
            // 
            // YEARPublished
            // 
            this.YEARPublished.Text = "YEARPublished";
            this.YEARPublished.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.YEARPublished.Width = 108;
            // 
            // QQH
            // 
            this.QQH.Text = "QQH";
            this.QQH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.QQH.Width = 100;
            // 
            // Category_type
            // 
            this.Category_type.Text = "Category_type";
            this.Category_type.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Category_type.Width = 99;
            // 
            // Publisher_name
            // 
            this.Publisher_name.Text = "Publisher_name";
            this.Publisher_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Publisher_name.Width = 109;
            // 
            // Author_Id
            // 
            this.Author_Id.Text = "Author_Id";
            this.Author_Id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Author_Id.Width = 104;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.ButtonCP5);
            this.GroupBox2.Controls.Add(this.ButtonListAll6);
            this.GroupBox2.Controls.Add(this.ButtonSearch6);
            this.GroupBox2.Controls.Add(this.ComboBox6);
            this.GroupBox2.Controls.Add(this.TextBoxSearch6);
            this.GroupBox2.Controls.Add(this.LabelEnter);
            this.GroupBox2.Controls.Add(this.LabelSearchBy);
            this.GroupBox2.Location = new System.Drawing.Point(510, 19);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(278, 213);
            this.GroupBox2.TabIndex = 7;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Search Books";
            // 
            // ButtonCP5
            // 
            this.ButtonCP5.Location = new System.Drawing.Point(61, 184);
            this.ButtonCP5.Name = "ButtonCP5";
            this.ButtonCP5.Size = new System.Drawing.Size(124, 23);
            this.ButtonCP5.TabIndex = 19;
            this.ButtonCP5.Text = "&Change Password";
            this.ButtonCP5.UseVisualStyleBackColor = true;
            this.ButtonCP5.Click += new System.EventHandler(this.ButtonCP5_Click);
            // 
            // ButtonListAll6
            // 
            this.ButtonListAll6.Location = new System.Drawing.Point(30, 149);
            this.ButtonListAll6.Name = "ButtonListAll6";
            this.ButtonListAll6.Size = new System.Drawing.Size(75, 23);
            this.ButtonListAll6.TabIndex = 15;
            this.ButtonListAll6.Text = "&List All";
            this.ButtonListAll6.UseVisualStyleBackColor = true;
            this.ButtonListAll6.Click += new System.EventHandler(this.ButtonListAll6_Click);
            // 
            // ButtonSearch6
            // 
            this.ButtonSearch6.Location = new System.Drawing.Point(142, 149);
            this.ButtonSearch6.Name = "ButtonSearch6";
            this.ButtonSearch6.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch6.TabIndex = 4;
            this.ButtonSearch6.Text = "Search";
            this.ButtonSearch6.UseVisualStyleBackColor = true;
            this.ButtonSearch6.Click += new System.EventHandler(this.ButtonSearch6_Click);
            // 
            // ComboBox6
            // 
            this.ComboBox6.FormattingEnabled = true;
            this.ComboBox6.Location = new System.Drawing.Point(61, 51);
            this.ComboBox6.Name = "ComboBox6";
            this.ComboBox6.Size = new System.Drawing.Size(121, 21);
            this.ComboBox6.TabIndex = 3;
            // 
            // TextBoxSearch6
            // 
            this.TextBoxSearch6.Location = new System.Drawing.Point(44, 113);
            this.TextBoxSearch6.Name = "TextBoxSearch6";
            this.TextBoxSearch6.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch6.TabIndex = 2;
            // 
            // LabelEnter
            // 
            this.LabelEnter.AutoSize = true;
            this.LabelEnter.Location = new System.Drawing.Point(41, 89);
            this.LabelEnter.Name = "LabelEnter";
            this.LabelEnter.Size = new System.Drawing.Size(188, 13);
            this.LabelEnter.TabIndex = 1;
            this.LabelEnter.Text = "Please Enter The keyword for search :";
            // 
            // LabelSearchBy
            // 
            this.LabelSearchBy.AutoSize = true;
            this.LabelSearchBy.Location = new System.Drawing.Point(85, 28);
            this.LabelSearchBy.Name = "LabelSearchBy";
            this.LabelSearchBy.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy.TabIndex = 0;
            this.LabelSearchBy.Text = "Search By";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.label1);
            this.GroupBox1.Controls.Add(this.ButtonReset6);
            this.GroupBox1.Controls.Add(this.TextBoxAuthorId);
            this.GroupBox1.Controls.Add(this.TextBoxPName);
            this.GroupBox1.Controls.Add(this.LabelPName);
            this.GroupBox1.Controls.Add(this.LabelAuthor_Id);
            this.GroupBox1.Controls.Add(this.TextBoxCT);
            this.GroupBox1.Controls.Add(this.ButtonExit6);
            this.GroupBox1.Controls.Add(this.LabelCT);
            this.GroupBox1.Controls.Add(this.ButtonDelete6);
            this.GroupBox1.Controls.Add(this.TextBoxQOH);
            this.GroupBox1.Controls.Add(this.ButtonUpdate6);
            this.GroupBox1.Controls.Add(this.TextBoxYP);
            this.GroupBox1.Controls.Add(this.ButtonSave6);
            this.GroupBox1.Controls.Add(this.TextBoxUnitPrice);
            this.GroupBox1.Controls.Add(this.TextBoxISBN);
            this.GroupBox1.Controls.Add(this.TextBoxTitle);
            this.GroupBox1.Controls.Add(this.LabelISBN);
            this.GroupBox1.Controls.Add(this.LabelQOH);
            this.GroupBox1.Controls.Add(this.LabelTitle);
            this.GroupBox1.Controls.Add(this.LabelYP);
            this.GroupBox1.Controls.Add(this.LabelUnitPrice);
            this.GroupBox1.Controls.Add(this.LabelDigits);
            this.GroupBox1.Location = new System.Drawing.Point(16, 19);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(475, 213);
            this.GroupBox1.TabIndex = 6;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Book Information";
            // 
            // ButtonReset6
            // 
            this.ButtonReset6.Location = new System.Drawing.Point(386, 149);
            this.ButtonReset6.Name = "ButtonReset6";
            this.ButtonReset6.Size = new System.Drawing.Size(75, 23);
            this.ButtonReset6.TabIndex = 34;
            this.ButtonReset6.Text = "&Reset";
            this.ButtonReset6.UseVisualStyleBackColor = true;
            this.ButtonReset6.Click += new System.EventHandler(this.ButtonReset6_Click);
            // 
            // TextBoxAuthorId
            // 
            this.TextBoxAuthorId.Location = new System.Drawing.Point(228, 173);
            this.TextBoxAuthorId.Name = "TextBoxAuthorId";
            this.TextBoxAuthorId.Size = new System.Drawing.Size(100, 20);
            this.TextBoxAuthorId.TabIndex = 33;
            // 
            // TextBoxPName
            // 
            this.TextBoxPName.Location = new System.Drawing.Point(108, 172);
            this.TextBoxPName.Name = "TextBoxPName";
            this.TextBoxPName.Size = new System.Drawing.Size(100, 20);
            this.TextBoxPName.TabIndex = 32;
            // 
            // LabelPName
            // 
            this.LabelPName.AutoSize = true;
            this.LabelPName.Location = new System.Drawing.Point(115, 153);
            this.LabelPName.Name = "LabelPName";
            this.LabelPName.Size = new System.Drawing.Size(82, 13);
            this.LabelPName.TabIndex = 30;
            this.LabelPName.Text = "Publisher_name";
            // 
            // LabelAuthor_Id
            // 
            this.LabelAuthor_Id.AutoSize = true;
            this.LabelAuthor_Id.Location = new System.Drawing.Point(252, 153);
            this.LabelAuthor_Id.Name = "LabelAuthor_Id";
            this.LabelAuthor_Id.Size = new System.Drawing.Size(53, 13);
            this.LabelAuthor_Id.TabIndex = 31;
            this.LabelAuthor_Id.Text = "Author_Id";
            // 
            // LabelUnitPrice
            // 
            this.LabelUnitPrice.AutoSize = true;
            this.LabelUnitPrice.Location = new System.Drawing.Point(278, 25);
            this.LabelUnitPrice.Name = "LabelUnitPrice";
            this.LabelUnitPrice.Size = new System.Drawing.Size(50, 13);
            this.LabelUnitPrice.TabIndex = 20;
            this.LabelUnitPrice.Text = "UnitPrice";
            // 
            // LabelDigits
            // 
            this.LabelDigits.AutoSize = true;
            this.LabelDigits.Location = new System.Drawing.Point(41, 69);
            this.LabelDigits.Name = "LabelDigits";
            this.LabelDigits.Size = new System.Drawing.Size(51, 13);
            this.LabelDigits.TabIndex = 21;
            this.LabelDigits.Text = "( 4 Digits)";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.ListView2);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(814, 387);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Author_Infomation";
            // 
            // ListView2
            // 
            this.ListView2.BackColor = System.Drawing.Color.Silver;
            this.ListView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.AuthorId,
            this.First_Name,
            this.Last_Name,
            this.Email});
            this.ListView2.GridLines = true;
            this.ListView2.Location = new System.Drawing.Point(21, 203);
            this.ListView2.Name = "ListView2";
            this.ListView2.Size = new System.Drawing.Size(772, 160);
            this.ListView2.TabIndex = 11;
            this.ListView2.UseCompatibleStateImageBehavior = false;
            this.ListView2.View = System.Windows.Forms.View.Details;
            this.ListView2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView2_MouseClick);
            // 
            // AuthorId
            // 
            this.AuthorId.Text = "Author_Id";
            this.AuthorId.Width = 89;
            // 
            // First_Name
            // 
            this.First_Name.Text = "First_Name";
            this.First_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.First_Name.Width = 91;
            // 
            // Last_Name
            // 
            this.Last_Name.Text = "Last_Name";
            this.Last_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Last_Name.Width = 96;
            // 
            // Email
            // 
            this.Email.Text = "Email";
            this.Email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Email.Width = 111;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "YYYY-MM-DD";
            // 
            // Form6Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(872, 441);
            this.Controls.Add(this.TabControl1);
            this.Name = "Form6Inventory";
            this.Text = "FormInventory";
            this.Load += new System.EventHandler(this.FormInventory_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button ButtonSearch7;
        private System.Windows.Forms.ComboBox ComboBox7;
        private System.Windows.Forms.TextBox TextBoxSearch7;
        private System.Windows.Forms.Label LabelSearch7;
        private System.Windows.Forms.Label LabelSearchBy7;
        private System.Windows.Forms.TextBox TextBoxCT;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox TextBoxEmail;
        private System.Windows.Forms.TextBox TextBoxPN;
        private System.Windows.Forms.TextBox TextBoxFN7;
        private System.Windows.Forms.Label LabelEmail6;
        private System.Windows.Forms.Label LabelLN6;
        private System.Windows.Forms.Label Label3Digits;
        private System.Windows.Forms.Label LabelFN6;
        private System.Windows.Forms.TextBox TextBoxAId;
        private System.Windows.Forms.Label LabelAuthorId;
        private System.Windows.Forms.Button ButtonListAll7;
        private System.Windows.Forms.Button ButtonDelete7;
        private System.Windows.Forms.Button ButtonUpdate7;
        private System.Windows.Forms.Button ButtonSave7;
        private System.Windows.Forms.Button ButtonExit6;
        private System.Windows.Forms.Label LabelCT;
        private System.Windows.Forms.Button ButtonDelete6;
        private System.Windows.Forms.TextBox TextBoxQOH;
        private System.Windows.Forms.Button ButtonUpdate6;
        private System.Windows.Forms.TextBox TextBoxYP;
        private System.Windows.Forms.Button ButtonSave6;
        private System.Windows.Forms.TextBox TextBoxUnitPrice;
        private System.Windows.Forms.TextBox TextBoxISBN;
        private System.Windows.Forms.TextBox TextBoxTitle;
        private System.Windows.Forms.Label LabelISBN;
        private System.Windows.Forms.Label LabelQOH;
        private System.Windows.Forms.Label LabelTitle;
        private System.Windows.Forms.Label LabelYP;
        private System.Windows.Forms.TabControl TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListView ListView1;
        private System.Windows.Forms.GroupBox GroupBox2;
        private System.Windows.Forms.Button ButtonListAll6;
        private System.Windows.Forms.Button ButtonSearch6;
        private System.Windows.Forms.ComboBox ComboBox6;
        private System.Windows.Forms.TextBox TextBoxSearch6;
        private System.Windows.Forms.Label LabelEnter;
        private System.Windows.Forms.Label LabelSearchBy;
        private System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.Label LabelUnitPrice;
        private System.Windows.Forms.Label LabelDigits;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView ListView2;
        private System.Windows.Forms.TextBox TextBoxAuthorId;
        private System.Windows.Forms.TextBox TextBoxPName;
        private System.Windows.Forms.Label LabelPName;
        private System.Windows.Forms.Label LabelAuthor_Id;
        private System.Windows.Forms.ColumnHeader ISBN;
        private System.Windows.Forms.ColumnHeader Title;
        private System.Windows.Forms.ColumnHeader UnitPrice;
        private System.Windows.Forms.ColumnHeader YEARPublished;
        private System.Windows.Forms.ColumnHeader QQH;
        private System.Windows.Forms.ColumnHeader Category_type;
        private System.Windows.Forms.ColumnHeader Publisher_name;
        private System.Windows.Forms.ColumnHeader Author_Id;
        private System.Windows.Forms.Button ButtonReset6;
        private System.Windows.Forms.Button ButtonExit7;
        private System.Windows.Forms.ColumnHeader AuthorId;
        private System.Windows.Forms.ColumnHeader First_Name;
        private System.Windows.Forms.ColumnHeader Last_Name;
        private System.Windows.Forms.ColumnHeader Email;
        private System.Windows.Forms.Button ButtonCP5;
        private System.Windows.Forms.Label label1;
    }
}