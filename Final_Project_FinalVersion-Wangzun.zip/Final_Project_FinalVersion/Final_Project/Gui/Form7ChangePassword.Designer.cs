﻿namespace Final_Project.Gui
{
    partial class Form7ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ButtonChange = new System.Windows.Forms.Button();
            this.TextBoxPasswordC = new System.Windows.Forms.TextBox();
            this.LabelPasswordC = new System.Windows.Forms.Label();
            this.TextBoxLoginID = new System.Windows.Forms.TextBox();
            this.LabelLoginID = new System.Windows.Forms.Label();
            this.TextBoxNewPass = new System.Windows.Forms.TextBox();
            this.LabelNewPassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.GhostWhite;
            this.label1.Location = new System.Drawing.Point(57, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 39);
            this.label1.TabIndex = 32;
            this.label1.Text = "Hi-Tech Distribution Inc.";
            // 
            // ButtonChange
            // 
            this.ButtonChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonChange.Location = new System.Drawing.Point(217, 263);
            this.ButtonChange.Name = "ButtonChange";
            this.ButtonChange.Size = new System.Drawing.Size(104, 36);
            this.ButtonChange.TabIndex = 31;
            this.ButtonChange.Text = "Change";
            this.ButtonChange.UseVisualStyleBackColor = true;
            this.ButtonChange.Click += new System.EventHandler(this.ButtonChange_Click);
            // 
            // TextBoxPasswordC
            // 
            this.TextBoxPasswordC.BackColor = System.Drawing.Color.Teal;
            this.TextBoxPasswordC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxPasswordC.Location = new System.Drawing.Point(273, 209);
            this.TextBoxPasswordC.Name = "TextBoxPasswordC";
            this.TextBoxPasswordC.Size = new System.Drawing.Size(166, 26);
            this.TextBoxPasswordC.TabIndex = 30;
            // 
            // LabelPasswordC
            // 
            this.LabelPasswordC.AutoSize = true;
            this.LabelPasswordC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPasswordC.Location = new System.Drawing.Point(70, 208);
            this.LabelPasswordC.Name = "LabelPasswordC";
            this.LabelPasswordC.Size = new System.Drawing.Size(197, 25);
            this.LabelPasswordC.TabIndex = 29;
            this.LabelPasswordC.Text = "Comfirm Password:";
            // 
            // TextBoxLoginID
            // 
            this.TextBoxLoginID.BackColor = System.Drawing.Color.Teal;
            this.TextBoxLoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxLoginID.Location = new System.Drawing.Point(273, 115);
            this.TextBoxLoginID.Name = "TextBoxLoginID";
            this.TextBoxLoginID.Size = new System.Drawing.Size(166, 26);
            this.TextBoxLoginID.TabIndex = 28;
            // 
            // LabelLoginID
            // 
            this.LabelLoginID.AutoSize = true;
            this.LabelLoginID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelLoginID.Location = new System.Drawing.Point(160, 115);
            this.LabelLoginID.Name = "LabelLoginID";
            this.LabelLoginID.Size = new System.Drawing.Size(103, 25);
            this.LabelLoginID.TabIndex = 27;
            this.LabelLoginID.Text = "Login ID :";
            // 
            // TextBoxNewPass
            // 
            this.TextBoxNewPass.BackColor = System.Drawing.Color.Teal;
            this.TextBoxNewPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxNewPass.Location = new System.Drawing.Point(273, 163);
            this.TextBoxNewPass.Name = "TextBoxNewPass";
            this.TextBoxNewPass.Size = new System.Drawing.Size(166, 26);
            this.TextBoxNewPass.TabIndex = 34;
            // 
            // LabelNewPassword
            // 
            this.LabelNewPassword.AutoSize = true;
            this.LabelNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNewPassword.Location = new System.Drawing.Point(103, 164);
            this.LabelNewPassword.Name = "LabelNewPassword";
            this.LabelNewPassword.Size = new System.Drawing.Size(160, 25);
            this.LabelNewPassword.TabIndex = 33;
            this.LabelNewPassword.Text = "New Password:";
            // 
            // Form7ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 331);
            this.Controls.Add(this.TextBoxNewPass);
            this.Controls.Add(this.LabelNewPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonChange);
            this.Controls.Add(this.TextBoxPasswordC);
            this.Controls.Add(this.LabelPasswordC);
            this.Controls.Add(this.TextBoxLoginID);
            this.Controls.Add(this.LabelLoginID);
            this.Name = "Form7ChangePassword";
            this.Text = "Form7ChangePassword";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonChange;
        private System.Windows.Forms.TextBox TextBoxPasswordC;
        private System.Windows.Forms.Label LabelPasswordC;
        private System.Windows.Forms.TextBox TextBoxLoginID;
        private System.Windows.Forms.Label LabelLoginID;
        private System.Windows.Forms.TextBox TextBoxNewPass;
        private System.Windows.Forms.Label LabelNewPassword;
    }
}