﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project.Gui
{
    public partial class Form3SalesManager : Form
    {
        
        //search categories
        public enum SearchBy
        {
            undefined, Customer_Id, Customer_Name, City, PostCode, PhoneNumber
        }

        //initialize
        DataSet CustomersDB;
        DataTable dtCustomers;
        SqlDataAdapter da;
        SqlConnection connDB = new SqlConnection("data source =.; database = FinalProjectDB;" +
                                                     " Integrated Security = SSPI");

        public Form3SalesManager()
        {
            InitializeComponent();
        }

        //load data from DB
        private void FormSalesManager_Load(object sender, EventArgs e)
        {
            foreach (SearchBy type in Enum.GetValues(typeof(SearchBy)))
            {
                this.ComboBoxSearch2.Items.Add(type);
            }
            this.ComboBoxSearch2.Text = Convert.ToString(ComboBoxSearch2.Items[0]);

            CustomersDB = new DataSet("CustomersDB");
            dtCustomers = new DataTable("Customers");

            dtCustomers.Columns.Add("Customer_Id", typeof(Int32));
            dtCustomers.Columns.Add("Customer_Name", typeof(string));
            dtCustomers.Columns.Add("Street", typeof(string));
            dtCustomers.Columns.Add("City", typeof(string));
            dtCustomers.Columns.Add("PostCode", typeof(string));
            dtCustomers.Columns.Add("PhoneNumber", typeof(string));
            dtCustomers.Columns.Add("FaxNumber", typeof(string));
            dtCustomers.Columns.Add("Credit_Limit", typeof(decimal));

            dtCustomers.PrimaryKey = new DataColumn[] { dtCustomers.Columns["Customer_Id"] };
            CustomersDB.Tables.Add(dtCustomers);

            da = new SqlDataAdapter("select * from Customers", connDB);
            da.Fill(CustomersDB.Tables["Customers"]);
            dataGridView1.DataSource = dtCustomers;
        }

        //button save
        private void ButtonSave2_Click(object sender, EventArgs e)
        {
            int Customer_Id = Convert.ToInt32(TextBoxID2.Text);
            string Customer_Name = TextBoxCN.Text;
            string Street = TextBoxStreet.Text;
            string City = TextBoxCity.Text;
            string PostCode = TextBoxPostCode.Text;
            decimal Credit_Limit = Convert.ToDecimal(TextBoxCL.Text);
            string PhoneNumber = TextBoxPN.Text;
            string FaxNumber = TextBoxFaxN.Text;
            
            //store inside the dataset not in DB
            dtCustomers.Rows.Add(Customer_Id, Customer_Name, Street, City, PostCode, 
                                    PhoneNumber, FaxNumber, Credit_Limit);

            //store data inside DB
            if (connDB.State == ConnectionState.Closed)
            {
                connDB.Open();
            }
            string que = string.Format("Insert into Customers values ('{0}','{1}','{2}','{3}','{4}','{5}',{6})"
                         , Customer_Name, Street, City, PostCode, PhoneNumber, FaxNumber, Credit_Limit);
          
            da.InsertCommand = new SqlCommand(que, connDB);
            da.Update(CustomersDB, "Customers");
            dataGridView1.DataSource = dtCustomers;

            MessageBox.Show("Data saved successfully!");
            connDB.Close();
            ClearTextBox();
        }

        //Button update
        private void ButtonUpdate2_Click(object sender, EventArgs e)
        {
            int Customer_Id = Convert.ToInt32(TextBoxID2.Text);
            string Customer_Name = TextBoxCN.Text;
            string Street = TextBoxStreet.Text;
            string City = TextBoxCity.Text;
            string PostCode = TextBoxPostCode.Text;
            decimal Credit_Limit = Convert.ToDecimal(TextBoxCL.Text);
            string PhoneNumber = TextBoxPN.Text;
            string FaxNumber = TextBoxFaxN.Text;

            //for update
            DataRow drCustomers = dtCustomers.Rows.Find(Customer_Id);
            drCustomers["Customer_Name"] = Customer_Name;
            drCustomers["Street"] = Street;
            drCustomers["City"] = City;
            drCustomers["PostCode"] = PostCode;
            drCustomers["Credit_Limit"] = Credit_Limit;
            drCustomers["PhoneNumber"] = PhoneNumber;
            drCustomers["FaxNumber"] = FaxNumber;

            if (connDB.State == ConnectionState.Closed)
            {
                connDB.Open();
            }

            string que = string.Format("Update Customers set Customer_Name = '{0}',Street ='{1}', " +
                " City = '{2}',PostCode ='{3}',PhoneNumber ='{4}',FaxNumber ='{5}',Credit_Limit ='{6}' " +
                "where Customer_Id = {7}", Customer_Name, Street, City, PostCode, PhoneNumber, FaxNumber,
                Credit_Limit, Customer_Id);

            da.UpdateCommand = new SqlCommand(que, connDB);
            da.Update(CustomersDB, "Customers");
            dataGridView1.DataSource = dtCustomers;

            MessageBox.Show("Data updated successfully!");
            connDB.Close();
            ClearTextBox();
        }

        //Button delete
        private void ButtonDelete2_Click(object sender, EventArgs e)
        {
            //delete data from dataset not DB
            int Customer_Id = Convert.ToInt32(TextBoxID2.Text);
            DataRow drCustomers = dtCustomers.Rows.Find(Customer_Id);
            drCustomers.Delete();

            //delete data from DB
            if (connDB.State == ConnectionState.Closed)
            {
                connDB.Open();
            }
            string que = string.Format("Delete from Customers where  Customer_Id= {0}", Customer_Id);
            da = new SqlDataAdapter();
            da.DeleteCommand = new SqlCommand(que, connDB);
            da.Update(CustomersDB, "Customers");

            MessageBox.Show("Data delete successfully!");

            connDB.Close();
            ClearTextBox();
        }

        //button search
        private void ButtonSearch2_Click(object sender, EventArgs e)
        {            
            DataTable newCustomersTable = new DataTable();
            DataTable dtCustomers2 = new DataTable();
            dtCustomers2 = dtCustomers.Copy();
            newCustomersTable = dtCustomers.Copy();

            //clear data from newCustomersTable
            newCustomersTable.Clear();

            if (CustomersDB.Tables.Contains("newCustomersTable") == false)
            {
                CustomersDB.Tables.Add("newCustomersTable");
            }

            if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[0]))
            {
                MessageBox.Show("search BY can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (TextBoxSearch2.Text == "")
            {
                MessageBox.Show("search keyword can't be empty", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string search = TextBoxSearch2.Text;

                if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[1]))
                {
                    foreach (DataRow row in dtCustomers2.Rows)
                    {
                        if (row["Customer_Id"].ToString() == search)
                        {
                            newCustomersTable.ImportRow(row);
                        }                       
                    }
                    if (newCustomersTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Customer not found !");
                        ComboBoxSearch2.Text = "";
                    }
                    string que = string.Format("Select * from Customers where Customer_Id = {0} ", search);
                    da.SelectCommand = new SqlCommand(que, connDB);
                }
                else if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[2]))
                {
                    foreach (DataRow row in dtCustomers2.Rows)
                    {
                        if (row["Customer_Name"].ToString() == search)
                        {
                            newCustomersTable.ImportRow(row);
                        }
                    }
                    if (newCustomersTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Customer not found !");
                        ComboBoxSearch2.Text = "";
                    }
                    string que = string.Format("select * from Customers where Customer_Name = {0} ", search);
                    da.SelectCommand = new SqlCommand(que, connDB);
                }
                else if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[3]))
                {
                    foreach (DataRow row in dtCustomers2.Rows)
                    {
                        if (row["City"].ToString() == search)
                        {
                            newCustomersTable.ImportRow(row);
                        }
                    }
                    if (newCustomersTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Customer not found !");
                        ComboBoxSearch2.Text = "";
                    }
                    string que = string.Format("select * from Customers where City = {0} ", search);
                    da.SelectCommand = new SqlCommand(que, connDB);
                }
                else if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[4]))
                {
                    foreach (DataRow row in dtCustomers2.Rows)
                    {
                        if (row["PostCode"].ToString() == search)
                        {
                            newCustomersTable.ImportRow(row);
                        }
                    }
                    if (newCustomersTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Customer not found !");
                        ComboBoxSearch2.Text = "";
                    }
                    string que = string.Format("select * from Customers where PostCode = {0} ", search);
                    da.SelectCommand = new SqlCommand(que, connDB);
                }
                else if (ComboBoxSearch2.Text == Convert.ToString(ComboBoxSearch2.Items[5]))
                {
                    foreach (DataRow row in dtCustomers2.Rows)
                    {
                        if (row["PhoneNumber"].ToString() == search)
                        {
                            newCustomersTable.ImportRow(row);
                        }
                    }
                    if (newCustomersTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Customer not found !");
                        ComboBoxSearch2.Text = "";
                    }
                    string que = string.Format("select * from Customers where PhoneNumber = {0} ", search);
                    da.SelectCommand = new SqlCommand(que, connDB);
                }

                dataGridView1.DataSource = newCustomersTable;
            }

            connDB.Close();
            TextBoxSearch2.Text = string.Empty;
            ClearTextBox();
        }

        //button listAll 
        private void ButtonList2_Click(object sender, EventArgs e)
        {
            da = new SqlDataAdapter("select * from Customers", connDB);
            da.Fill(CustomersDB.Tables["Customers"]);
            dataGridView1.DataSource = dtCustomers;
        }

        //button reset
        private void ButtonReset_Click(object sender, EventArgs e)
        {
            TextBoxID2.Text = string.Empty;
            TextBoxCN.Text = string.Empty;
            TextBoxStreet.Text = string.Empty;
            TextBoxCity.Text = string.Empty;
            TextBoxPostCode.Text = string.Empty;
            TextBoxCL.Text = string.Empty;
            TextBoxPN.Text = string.Empty;
            TextBoxFaxN.Text = string.Empty;
            TextBoxID2.Focus();
        }

        //button exit
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome for use, see you next time !");
            this.Close();
        }



        //choose and show inside the datagridview
        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                TextBoxID2.Text = row.Cells["Customer_Id"].Value.ToString();
                TextBoxCN.Text = row.Cells["Customer_Name"].Value.ToString();
                TextBoxStreet.Text = row.Cells["Street"].Value.ToString();
                TextBoxCity.Text = row.Cells["City"].Value.ToString();
                TextBoxPostCode.Text = row.Cells["PostCode"].Value.ToString();
                TextBoxCL.Text = row.Cells["Credit_Limit"].Value.ToString();
                TextBoxPN.Text = row.Cells["PhoneNumber"].Value.ToString();
                TextBoxFaxN.Text = row.Cells["FaxNumber"].Value.ToString();
            }
        }

        //clear input 
        private void ClearTextBox()
        {
            TextBoxID2.Text = string.Empty;
            TextBoxCN.Text = string.Empty;
            TextBoxStreet.Text = string.Empty;
            TextBoxCity.Text = string.Empty;
            TextBoxPostCode.Text = string.Empty;
            TextBoxCL.Text = string.Empty;
            TextBoxPN.Text = string.Empty;
            TextBoxFaxN.Text = string.Empty;
        }

        private void ButtonCP2_Click(object sender, EventArgs e)
        {
            Form7ChangePassword form7 = new Form7ChangePassword();
            this.Hide();
            form7.ShowDialog();
            this.Close();
        }
    }
}
