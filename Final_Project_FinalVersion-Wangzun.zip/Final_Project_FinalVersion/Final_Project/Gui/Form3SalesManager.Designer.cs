﻿namespace Final_Project.Gui
{
    partial class Form3SalesManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.ButtonCP2 = new System.Windows.Forms.Button();
            this.ButtonList2 = new System.Windows.Forms.Button();
            this.ButtonSearch2 = new System.Windows.Forms.Button();
            this.ComboBoxSearch2 = new System.Windows.Forms.ComboBox();
            this.TextBoxSearch2 = new System.Windows.Forms.TextBox();
            this.LabelEnter2 = new System.Windows.Forms.Label();
            this.LabelSearchBy2 = new System.Windows.Forms.Label();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.ButtonReset = new System.Windows.Forms.Button();
            this.TextBoxFaxN = new System.Windows.Forms.TextBox();
            this.TextBoxPN = new System.Windows.Forms.TextBox();
            this.LabelFaxN = new System.Windows.Forms.Label();
            this.LabelPN = new System.Windows.Forms.Label();
            this.TextBoxCL = new System.Windows.Forms.TextBox();
            this.LabelCL = new System.Windows.Forms.Label();
            this.ButtonExit = new System.Windows.Forms.Button();
            this.ButtonDelete2 = new System.Windows.Forms.Button();
            this.ButtonUpdate2 = new System.Windows.Forms.Button();
            this.ButtonSave2 = new System.Windows.Forms.Button();
            this.TextBoxPostCode = new System.Windows.Forms.TextBox();
            this.TextBoxCity = new System.Windows.Forms.TextBox();
            this.TextBoxStreet = new System.Windows.Forms.TextBox();
            this.TextBoxCN = new System.Windows.Forms.TextBox();
            this.LabelPostCode = new System.Windows.Forms.Label();
            this.LabelCity = new System.Windows.Forms.Label();
            this.Label3Digits2 = new System.Windows.Forms.Label();
            this.LabelStreet = new System.Windows.Forms.Label();
            this.LabelCN = new System.Windows.Forms.Label();
            this.TextBoxID2 = new System.Windows.Forms.TextBox();
            this.LabelID2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.GroupBox4.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupBox4
            // 
            this.GroupBox4.BackColor = System.Drawing.Color.Silver;
            this.GroupBox4.Controls.Add(this.ButtonCP2);
            this.GroupBox4.Controls.Add(this.ButtonList2);
            this.GroupBox4.Controls.Add(this.ButtonSearch2);
            this.GroupBox4.Controls.Add(this.ComboBoxSearch2);
            this.GroupBox4.Controls.Add(this.TextBoxSearch2);
            this.GroupBox4.Controls.Add(this.LabelEnter2);
            this.GroupBox4.Controls.Add(this.LabelSearchBy2);
            this.GroupBox4.Location = new System.Drawing.Point(539, 25);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(236, 224);
            this.GroupBox4.TabIndex = 7;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Search Customer";
            // 
            // ButtonCP2
            // 
            this.ButtonCP2.Location = new System.Drawing.Point(50, 195);
            this.ButtonCP2.Name = "ButtonCP2";
            this.ButtonCP2.Size = new System.Drawing.Size(124, 23);
            this.ButtonCP2.TabIndex = 19;
            this.ButtonCP2.Text = "&Change Password";
            this.ButtonCP2.UseVisualStyleBackColor = true;
            this.ButtonCP2.Click += new System.EventHandler(this.ButtonCP2_Click);
            // 
            // ButtonList2
            // 
            this.ButtonList2.Location = new System.Drawing.Point(19, 158);
            this.ButtonList2.Name = "ButtonList2";
            this.ButtonList2.Size = new System.Drawing.Size(75, 23);
            this.ButtonList2.TabIndex = 15;
            this.ButtonList2.Text = "&List All";
            this.ButtonList2.UseVisualStyleBackColor = true;
            this.ButtonList2.Click += new System.EventHandler(this.ButtonList2_Click);
            // 
            // ButtonSearch2
            // 
            this.ButtonSearch2.Location = new System.Drawing.Point(122, 158);
            this.ButtonSearch2.Name = "ButtonSearch2";
            this.ButtonSearch2.Size = new System.Drawing.Size(75, 23);
            this.ButtonSearch2.TabIndex = 4;
            this.ButtonSearch2.Text = "Search";
            this.ButtonSearch2.UseVisualStyleBackColor = true;
            this.ButtonSearch2.Click += new System.EventHandler(this.ButtonSearch2_Click);
            // 
            // ComboBoxSearch2
            // 
            this.ComboBoxSearch2.FormattingEnabled = true;
            this.ComboBoxSearch2.Location = new System.Drawing.Point(50, 53);
            this.ComboBoxSearch2.Name = "ComboBoxSearch2";
            this.ComboBoxSearch2.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxSearch2.TabIndex = 3;
            // 
            // TextBoxSearch2
            // 
            this.TextBoxSearch2.Location = new System.Drawing.Point(50, 115);
            this.TextBoxSearch2.Name = "TextBoxSearch2";
            this.TextBoxSearch2.Size = new System.Drawing.Size(138, 20);
            this.TextBoxSearch2.TabIndex = 2;
            // 
            // LabelEnter2
            // 
            this.LabelEnter2.AutoSize = true;
            this.LabelEnter2.Location = new System.Drawing.Point(26, 94);
            this.LabelEnter2.Name = "LabelEnter2";
            this.LabelEnter2.Size = new System.Drawing.Size(185, 13);
            this.LabelEnter2.TabIndex = 1;
            this.LabelEnter2.Text = "Please Enter The keyword for search:";
            // 
            // LabelSearchBy2
            // 
            this.LabelSearchBy2.AutoSize = true;
            this.LabelSearchBy2.Location = new System.Drawing.Point(65, 27);
            this.LabelSearchBy2.Name = "LabelSearchBy2";
            this.LabelSearchBy2.Size = new System.Drawing.Size(56, 13);
            this.LabelSearchBy2.TabIndex = 0;
            this.LabelSearchBy2.Text = "Search By";
            // 
            // GroupBox3
            // 
            this.GroupBox3.BackColor = System.Drawing.Color.Silver;
            this.GroupBox3.Controls.Add(this.label1);
            this.GroupBox3.Controls.Add(this.ButtonReset);
            this.GroupBox3.Controls.Add(this.TextBoxFaxN);
            this.GroupBox3.Controls.Add(this.TextBoxPN);
            this.GroupBox3.Controls.Add(this.LabelFaxN);
            this.GroupBox3.Controls.Add(this.LabelPN);
            this.GroupBox3.Controls.Add(this.TextBoxCL);
            this.GroupBox3.Controls.Add(this.LabelCL);
            this.GroupBox3.Controls.Add(this.ButtonExit);
            this.GroupBox3.Controls.Add(this.ButtonDelete2);
            this.GroupBox3.Controls.Add(this.ButtonUpdate2);
            this.GroupBox3.Controls.Add(this.ButtonSave2);
            this.GroupBox3.Controls.Add(this.TextBoxPostCode);
            this.GroupBox3.Controls.Add(this.TextBoxCity);
            this.GroupBox3.Controls.Add(this.TextBoxStreet);
            this.GroupBox3.Controls.Add(this.TextBoxCN);
            this.GroupBox3.Controls.Add(this.LabelPostCode);
            this.GroupBox3.Controls.Add(this.LabelCity);
            this.GroupBox3.Controls.Add(this.Label3Digits2);
            this.GroupBox3.Controls.Add(this.LabelStreet);
            this.GroupBox3.Controls.Add(this.LabelCN);
            this.GroupBox3.Controls.Add(this.TextBoxID2);
            this.GroupBox3.Controls.Add(this.LabelID2);
            this.GroupBox3.Location = new System.Drawing.Point(18, 25);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(491, 224);
            this.GroupBox3.TabIndex = 6;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Customer Information";
            // 
            // ButtonReset
            // 
            this.ButtonReset.Location = new System.Drawing.Point(380, 143);
            this.ButtonReset.Name = "ButtonReset";
            this.ButtonReset.Size = new System.Drawing.Size(75, 23);
            this.ButtonReset.TabIndex = 21;
            this.ButtonReset.Text = "&Reset";
            this.ButtonReset.UseVisualStyleBackColor = true;
            this.ButtonReset.Click += new System.EventHandler(this.ButtonReset_Click);
            // 
            // TextBoxFaxN
            // 
            this.TextBoxFaxN.Location = new System.Drawing.Point(189, 186);
            this.TextBoxFaxN.Name = "TextBoxFaxN";
            this.TextBoxFaxN.Size = new System.Drawing.Size(163, 20);
            this.TextBoxFaxN.TabIndex = 20;
            // 
            // TextBoxPN
            // 
            this.TextBoxPN.Location = new System.Drawing.Point(19, 186);
            this.TextBoxPN.Name = "TextBoxPN";
            this.TextBoxPN.Size = new System.Drawing.Size(154, 20);
            this.TextBoxPN.TabIndex = 19;
            // 
            // LabelFaxN
            // 
            this.LabelFaxN.AutoSize = true;
            this.LabelFaxN.Location = new System.Drawing.Point(238, 169);
            this.LabelFaxN.Name = "LabelFaxN";
            this.LabelFaxN.Size = new System.Drawing.Size(61, 13);
            this.LabelFaxN.TabIndex = 18;
            this.LabelFaxN.Text = "FaxNumber";
            // 
            // LabelPN
            // 
            this.LabelPN.AutoSize = true;
            this.LabelPN.Location = new System.Drawing.Point(60, 168);
            this.LabelPN.Name = "LabelPN";
            this.LabelPN.Size = new System.Drawing.Size(75, 13);
            this.LabelPN.TabIndex = 17;
            this.LabelPN.Text = "PhoneNumber";
            // 
            // TextBoxCL
            // 
            this.TextBoxCL.Location = new System.Drawing.Point(252, 126);
            this.TextBoxCL.Name = "TextBoxCL";
            this.TextBoxCL.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCL.TabIndex = 16;
            // 
            // LabelCL
            // 
            this.LabelCL.AutoSize = true;
            this.LabelCL.Location = new System.Drawing.Point(272, 109);
            this.LabelCL.Name = "LabelCL";
            this.LabelCL.Size = new System.Drawing.Size(58, 13);
            this.LabelCL.TabIndex = 15;
            this.LabelCL.Text = "Credit Limit";
            // 
            // ButtonExit
            // 
            this.ButtonExit.Location = new System.Drawing.Point(380, 183);
            this.ButtonExit.Name = "ButtonExit";
            this.ButtonExit.Size = new System.Drawing.Size(75, 23);
            this.ButtonExit.TabIndex = 14;
            this.ButtonExit.Text = "&Exit";
            this.ButtonExit.UseVisualStyleBackColor = true;
            this.ButtonExit.Click += new System.EventHandler(this.ButtonExit_Click);
            // 
            // ButtonDelete2
            // 
            this.ButtonDelete2.Location = new System.Drawing.Point(380, 105);
            this.ButtonDelete2.Name = "ButtonDelete2";
            this.ButtonDelete2.Size = new System.Drawing.Size(75, 23);
            this.ButtonDelete2.TabIndex = 13;
            this.ButtonDelete2.Text = "&Delete";
            this.ButtonDelete2.UseVisualStyleBackColor = true;
            this.ButtonDelete2.Click += new System.EventHandler(this.ButtonDelete2_Click);
            // 
            // ButtonUpdate2
            // 
            this.ButtonUpdate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonUpdate2.Location = new System.Drawing.Point(380, 64);
            this.ButtonUpdate2.Name = "ButtonUpdate2";
            this.ButtonUpdate2.Size = new System.Drawing.Size(75, 23);
            this.ButtonUpdate2.TabIndex = 12;
            this.ButtonUpdate2.Text = "&Update";
            this.ButtonUpdate2.UseVisualStyleBackColor = true;
            this.ButtonUpdate2.Click += new System.EventHandler(this.ButtonUpdate2_Click);
            // 
            // ButtonSave2
            // 
            this.ButtonSave2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave2.Location = new System.Drawing.Point(380, 23);
            this.ButtonSave2.Name = "ButtonSave2";
            this.ButtonSave2.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave2.TabIndex = 11;
            this.ButtonSave2.Text = "&Save";
            this.ButtonSave2.UseVisualStyleBackColor = true;
            this.ButtonSave2.Click += new System.EventHandler(this.ButtonSave2_Click);
            // 
            // TextBoxPostCode
            // 
            this.TextBoxPostCode.Location = new System.Drawing.Point(137, 126);
            this.TextBoxPostCode.Name = "TextBoxPostCode";
            this.TextBoxPostCode.Size = new System.Drawing.Size(100, 20);
            this.TextBoxPostCode.TabIndex = 10;
            // 
            // TextBoxCity
            // 
            this.TextBoxCity.Location = new System.Drawing.Point(19, 126);
            this.TextBoxCity.Name = "TextBoxCity";
            this.TextBoxCity.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCity.TabIndex = 9;
            // 
            // TextBoxStreet
            // 
            this.TextBoxStreet.Location = new System.Drawing.Point(252, 53);
            this.TextBoxStreet.Name = "TextBoxStreet";
            this.TextBoxStreet.Size = new System.Drawing.Size(100, 20);
            this.TextBoxStreet.TabIndex = 8;
            // 
            // TextBoxCN
            // 
            this.TextBoxCN.Location = new System.Drawing.Point(135, 53);
            this.TextBoxCN.Name = "TextBoxCN";
            this.TextBoxCN.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCN.TabIndex = 7;
            // 
            // LabelPostCode
            // 
            this.LabelPostCode.AutoSize = true;
            this.LabelPostCode.Location = new System.Drawing.Point(157, 109);
            this.LabelPostCode.Name = "LabelPostCode";
            this.LabelPostCode.Size = new System.Drawing.Size(53, 13);
            this.LabelPostCode.TabIndex = 6;
            this.LabelPostCode.Text = "PostCode";
            // 
            // LabelCity
            // 
            this.LabelCity.AutoSize = true;
            this.LabelCity.Location = new System.Drawing.Point(45, 109);
            this.LabelCity.Name = "LabelCity";
            this.LabelCity.Size = new System.Drawing.Size(24, 13);
            this.LabelCity.TabIndex = 5;
            this.LabelCity.Text = "City";
            // 
            // Label3Digits2
            // 
            this.Label3Digits2.AutoSize = true;
            this.Label3Digits2.Location = new System.Drawing.Point(34, 80);
            this.Label3Digits2.Name = "Label3Digits2";
            this.Label3Digits2.Size = new System.Drawing.Size(51, 13);
            this.Label3Digits2.TabIndex = 4;
            this.Label3Digits2.Text = "( 3 Digits)";
            // 
            // LabelStreet
            // 
            this.LabelStreet.AutoSize = true;
            this.LabelStreet.Location = new System.Drawing.Point(276, 32);
            this.LabelStreet.Name = "LabelStreet";
            this.LabelStreet.Size = new System.Drawing.Size(35, 13);
            this.LabelStreet.TabIndex = 3;
            this.LabelStreet.Text = "Street";
            // 
            // LabelCN
            // 
            this.LabelCN.AutoSize = true;
            this.LabelCN.Location = new System.Drawing.Point(141, 32);
            this.LabelCN.Name = "LabelCN";
            this.LabelCN.Size = new System.Drawing.Size(82, 13);
            this.LabelCN.TabIndex = 2;
            this.LabelCN.Text = "Customer Name";
            // 
            // TextBoxID2
            // 
            this.TextBoxID2.Location = new System.Drawing.Point(19, 53);
            this.TextBoxID2.Name = "TextBoxID2";
            this.TextBoxID2.Size = new System.Drawing.Size(100, 20);
            this.TextBoxID2.TabIndex = 1;
            // 
            // LabelID2
            // 
            this.LabelID2.AutoSize = true;
            this.LabelID2.Location = new System.Drawing.Point(31, 32);
            this.LabelID2.Name = "LabelID2";
            this.LabelID2.Size = new System.Drawing.Size(65, 13);
            this.LabelID2.TabIndex = 0;
            this.LabelID2.Text = "Customer ID";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.GridColor = System.Drawing.Color.Silver;
            this.dataGridView1.Location = new System.Drawing.Point(18, 264);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(757, 198);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(157, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "A1A1A1";
            // 
            // Form3SalesManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(802, 474);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.GroupBox3);
            this.Name = "Form3SalesManager";
            this.Text = "FormSalesManager";
            this.Load += new System.EventHandler(this.FormSalesManager_Load);
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox GroupBox4;
        private System.Windows.Forms.Button ButtonSearch2;
        private System.Windows.Forms.ComboBox ComboBoxSearch2;
        private System.Windows.Forms.TextBox TextBoxSearch2;
        private System.Windows.Forms.Label LabelEnter2;
        private System.Windows.Forms.Label LabelSearchBy2;
        private System.Windows.Forms.GroupBox GroupBox3;
        private System.Windows.Forms.Button ButtonExit;
        private System.Windows.Forms.Button ButtonDelete2;
        private System.Windows.Forms.Button ButtonUpdate2;
        private System.Windows.Forms.Button ButtonSave2;
        private System.Windows.Forms.TextBox TextBoxPostCode;
        private System.Windows.Forms.TextBox TextBoxCity;
        private System.Windows.Forms.TextBox TextBoxStreet;
        private System.Windows.Forms.TextBox TextBoxCN;
        private System.Windows.Forms.Label LabelPostCode;
        private System.Windows.Forms.Label LabelCity;
        private System.Windows.Forms.Label Label3Digits2;
        private System.Windows.Forms.Label LabelStreet;
        private System.Windows.Forms.Label LabelCN;
        private System.Windows.Forms.TextBox TextBoxID2;
        private System.Windows.Forms.Label LabelID2;
        private System.Windows.Forms.TextBox TextBoxFaxN;
        private System.Windows.Forms.TextBox TextBoxPN;
        private System.Windows.Forms.Label LabelFaxN;
        private System.Windows.Forms.Label LabelPN;
        private System.Windows.Forms.TextBox TextBoxCL;
        private System.Windows.Forms.Label LabelCL;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ButtonList2;
        private System.Windows.Forms.Button ButtonReset;
        private System.Windows.Forms.Button ButtonCP2;
        private System.Windows.Forms.Label label1;
    }
}