﻿using Final_Project.Business;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.DataAccess
{
    public static class LoginDB
    {
        public static SqlConnection connDB = UtilityDB.ConnDB();
        public static SqlCommand cmd = new SqlCommand();

        //-----------------login---------------------
        //search login data function
        public static DataTable SearchUsers(Login login)
        {
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }

                cmd.Connection = connDB;
                cmd.CommandText = string.Format("select * from Users where Login_Id = {0} and Password = '{1}' ",
                                                login.Login_Id, login.Password);

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                reader.Close();
                cmd.Dispose();
                connDB.Close();

                return dt;
            }
            catch
            {
                return null;
            }
        }
        
        //-----------------change password---------------------
        //search login Id exist function
        public static DataTable SearchUsersExist(Login login)
        {
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }

                cmd.Connection = connDB;
                cmd.CommandText = string.Format("select * from Users where Login_Id = {0} ", login.Login_Id);

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                reader.Close();
                cmd.Dispose();
                connDB.Close();

                return dt;
            }
            catch
            {
                return null;
            }
        }

        //change password  function
        public static DataTable ChangePass(Login login)
        {
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }

                cmd.Connection = connDB;
                cmd.CommandText = string.Format("Update Users set Password = '{0}' where Login_Id = {1} ",
                                                login.Password, login.Login_Id);

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                reader.Close();
                cmd.Dispose();
                connDB.Close();

                return dt;
            }
            catch
            {
                return null;
            }
        }
    }
}
