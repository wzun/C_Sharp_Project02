﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

namespace Final_Project.DataAccess
{
    class UtilityDB
    {
        public static SqlConnection ConnDB()
        {
            try
            {
                SqlConnection connDB = new SqlConnection(
                    "data source=. ; database=FinalProjectDB; Integrated Security =SSPI ");
                //SqlConnection con = new SqlConnection("data source= . ; database=sample;
                //user =sa; password=demo");
                connDB.Open();
                return connDB;
            }
            catch
            {
                return null;
            }
        }
    }
}
