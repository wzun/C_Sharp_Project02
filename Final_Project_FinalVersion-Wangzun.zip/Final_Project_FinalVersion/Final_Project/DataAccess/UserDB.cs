﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Final_Project.Business;

namespace Final_Project.DataAccess
{
    public static class UsersDB
    {
        public static SqlConnection connDB = UtilityDB.ConnDB();
        public static SqlCommand cmd = new SqlCommand();

        //load data ,list and put into listview
        public static DataTable ListUsers()
        {
            if (connDB.State == ConnectionState.Closed)
            {
                connDB = UtilityDB.ConnDB();
                cmd = new SqlCommand();
            }
            cmd.Connection = connDB;
            cmd.CommandText = "select * from Users";

            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);

            reader.Close();
            cmd.Dispose();
            connDB.Close();

            return dt;
        }

        //save user into DB           
        public static bool SaveUsers(Users user)
        {
            bool state = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("insert into Users values ('{0}','{1}','{2}', {3},'{4}')",
                          user.First_Name, user.Last_Name, user.Department, user.Login_Id, user.Password );

                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch
            {
                state = false;
            }
            return state;
        }

        //update data from DB
        public static bool UpdateUsers(Users user)
        {
            bool state = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format(" Update Users set First_Name = '{0}', " +
                    " Last_Name = '{1}',  Department= '{2}',  Login_Id= {3},  Password= '{4}' " +
                    "where User_Id = {5} ", user.First_Name, user.Last_Name, user.Department,
                    user.Login_Id, user.Password ,user.User_Id);

                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch
            {
                state = false;
            }
            return state;
        }

        //delete data form DB
        public static bool DeleteUsers(Users user)
        {
            bool result = true;
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }
                cmd.Connection = connDB;
                cmd.CommandText = string.Format("Delete from Users where User_Id = {0}", user.User_Id);

                cmd.ExecuteNonQuery();
                connDB.Close();
            }
            catch
            {
                result = false;
            }
            return result;
        }
       
        //search data from DB
        public static DataTable SearchUsers(Users user)
        {
            try
            {
                if (connDB.State == ConnectionState.Closed)
                {
                    connDB = UtilityDB.ConnDB();
                    cmd = new SqlCommand();
                }

                cmd.Connection = connDB;
                cmd.CommandText = string.Format("select * from Users where User_Id = {0} or First_Name = '{1}' " +
                    "or Last_Name = '{2}' or Department= '{3}' or Login_Id = {4} ", user.User_Id, user.First_Name,
                    user.Last_Name, user.Department, user.Login_Id);

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                reader.Close();
                cmd.Dispose();
                connDB.Close();

                return dt;
            }
            catch
            {
                return null;
            }
        }
        
    }
}
