﻿using Final_Project.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Business
{
    public class Login
    {
        private int login_Id;
        private string password;

        public int Login_Id { get => login_Id; set => login_Id = value; }
        public string Password { get => password; set => password = value; }

        //-------login---------
        public DataTable SearchUsers(Login login)
        {
            return LoginDB.SearchUsers(login);
        }

        //-------change password 1---------
        public DataTable SearchUsersExist(Login login)
        {
            return LoginDB.SearchUsersExist(login);
        }

        //-------change password 2---------
        public DataTable ChangePass(Login login)
        {
            return LoginDB.ChangePass(login);
        }
    }
}
