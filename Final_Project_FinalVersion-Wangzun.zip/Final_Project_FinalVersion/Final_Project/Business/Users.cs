﻿using Final_Project.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project.Business
{
    public class Users
    {
        private int user_Id;
        private string first_Name;
        private string last_Name;
        private string department;
        private int login_Id;
        private string password;

        public int User_Id { get => user_Id; set => user_Id = value; }
        public string First_Name { get => first_Name; set => first_Name = value; }
        public string Last_Name { get => last_Name; set => last_Name = value; }
        public string Department { get => department; set => department = value; }
        public int Login_Id { get => login_Id; set => login_Id = value; }
        public string Password { get => password; set => password = value; }
        
        //---------------------------------------------------------------------------------

        // list and put into listview
        public DataTable ListUsers()
        {
            return UsersDB.ListUsers();
        }

        // save data into DB
        public bool SaveUsers(Users user)
        {
            return UsersDB.SaveUsers(user);
        }

        // update DB
        public bool UpdateUsers(Users user)
        {
            return UsersDB.UpdateUsers(user);
        }

        // delete from DB
        public bool DeleteUsers(Users user)
        {
            return UsersDB.DeleteUsers(user);
        }
        
        // search from DB
        public DataTable SearchUsers(Users user)
        {
            return UsersDB.SearchUsers(user);
        }
       
    }
}
